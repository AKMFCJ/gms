# -*- coding:utf-8 -*-
__author__ = 'changjie.fan'

"""Excel文件读写操作"""
import os

import pyexcel as pe
import pyexcel.ext.xlsx
import pyexcel.ext.xls
from openpyxl.workbook import Workbook
from openpyxl.writer.excel import ExcelWriter
from openpyxl.cell import get_column_letter
from openpyxl.cell import Cell

from wmt.wording.models import Wording


class WordingValueObject:
    def __init__(self, path, name, description, sub_description, whole_string):
        self.path = path
        self.name = name
        self.description = description
        self.sub_description = sub_description
        self.whole_string = whole_string
        self.language_value = {}


class ExcelOptions:
    def __init__(self, file_path):
        self.file_path = file_path

    def read_records(self, project_name, platform):
        records = pe.get_records(file_name=self.file_path)
        result = []

        project_dir_name = '/' + project_name + '/'

        for record in records:
            if record['Relative Path'].strip() and record['Relative Path'].strip().endswith('.xml'):
                wording_obj = Wording()
                relative_path = record['Relative Path'].replace('\\', '/')
                path = ''
                if platform == 'APP':
                    if relative_path.find(project_dir_name) > 0:
                        path = relative_path.split(project_dir_name)[1]
                else:
                    if relative_path.find('/frameworks/') > 0:
                        path = relative_path.split('/frameworks/')[1]
                    elif relative_path.find('/packages/') > 0:
                        path = relative_path.split('/packages/')[1]
                    elif relative_path.find('/vendor/tinno/tinnoapps/') > 0:
                        path = os.path.join('tinnoapps', relative_path.split('/vendor/tinno/tinnoapps/')[1])
                    elif relative_path.find('/vendor/qcom/') > 0:
                        path = os.path.join('qcom', relative_path.split('/vendor/qcom/')[1])

                if not path:
                    return []

                wording_obj.abs_path = os.path.join(path, record['name']).strip()
                wording_obj.path = path
                wording_obj.name = record['name'].strip()
                wording_obj.description = record['Description'].strip()
                wording_obj.sub_description = record['Sub-Description'].strip()
                wording_obj.whole_string = record['Whole String'].strip()
                wording_obj.size = len(wording_obj.whole_string)

                result.append(wording_obj)

        return result

    def read_abs_path(self):
        # 读取Excel中字串所在xml的绝度路径
        records = pe.get_records(file_name=self.file_path)
        result = {}

        for record in records:
            if record['Relative Path'].strip() and record['Relative Path'].strip().endswith('.xml'):
                relative_path = record['Relative Path'].replace('\\', '/')
                if relative_path.find('/frameworks/') > 0:
                    path = relative_path.split('/frameworks/')[1]
                elif relative_path.find('/packages/') > 0:
                    path = relative_path.split('/packages/')[1]

                result[os.path.join(path, record['name'].strip())] = relative_path

        return result

    def export_xls(self, wording_value, work_language, languages, current_app):
        """导出翻译结果"""

        wb = Workbook()
        ew = ExcelWriter(workbook=wb)
        ws_string = wb.worksheets[0]

        wording_row_01 = [u'Relative Path', u'name', u'Description', u'Sub-Description', u'Whole String']
        wording_row_02 = [u'PATH', u'NAME', u'COMMENT', u'ITEM COMMENT', u'STRING CONTENT']

        # 表头
        index = 1
        for row, cell in enumerate(wording_row_01):
            col = get_column_letter(index)
            ws_string.cell("%s%s" % (col, 1)).value = cell
            index += 1

        # 表头
        index = 1
        for cell in wording_row_02:
            col = get_column_letter(index)
            ws_string.cell("%s%s" % (col, 2)).value = cell
            index += 1

        # 语言全称和缩写
        work_language.sort()
        for language in work_language:
            col = get_column_letter(index)
            ws_string.cell("%s%s" % (col, 1)).value = languages[language]
            ws_string.cell("%s%s" % (col, 2)).value = language
            index += 1

        index = 1
        row = 3
        for abs_path, wording_value_obj in wording_value.items():
            col = get_column_letter(index)
            ws_string.cell("%s%s" % (col, row)).value = wording_value_obj.path
            index += 1
            col = get_column_letter(index)
            ws_string.cell("%s%s" % (col, row)).value = wording_value_obj.name
            index += 1
            col = get_column_letter(index)
            ws_string.cell("%s%s" % (col, row)).value = wording_value_obj.description
            index += 1
            col = get_column_letter(index)
            ws_string.cell("%s%s" % (col, row)).value = wording_value_obj.sub_description
            index += 1
            col = get_column_letter(index)
            ws_string.cell("%s%s" % (col, row)).value = wording_value_obj.whole_string
            index += 1
            col = get_column_letter(index)

            languages = wording_value_obj.language_value.keys()
            languages.sort()
            for language in languages:
                ws_string.cell("%s%s" % (col, row)).value = wording_value_obj.language_value[language]
                index += 1
                col = get_column_letter(index)
            row += 1
            index = 1

        ew.save(filename=self.file_path)

        # wb = xlwt.Workbook(encoding="utf8")

        # wording_row_01 = [u'Relative Path', u'name', u'Description', u'Sub-Description', u'Whole String']
        # wording_row_02 = [u'PATH', u'NAME', u'COMMENT', u'ITEM COMMENT', u'STRING CONTENT']
        # ws_string = wb.add_sheet(u"Sheet0")
        # row = 0
        #
        # work_language.sort()
        # for language in work_language:
        #     wording_row_02.append(language)
        #
        # # 表头
        # for index, cell in enumerate(wording_row_01):
        #     ws_string.write(row, index, cell)
        # row += 1
        # # 表头
        # index = 0
        # for cell in wording_row_02:
        #     ws_string.write(row, index, cell)
        #     index += 1
        #
        # row += 1
        # for abs_path, wording_value_obj in wording_value.items():
        #     ws_string.write(row, 0, wording_value_obj.path)
        #     ws_string.write(row, 1, wording_value_obj.name)
        #     ws_string.write(row, 2, wording_value_obj.description)
        #     ws_string.write(row, 3, wording_value_obj.sub_description)
        #     ws_string.write(row, 4, wording_value_obj.whole_string)
        #     index = 5
        #     languages = wording_value_obj.language_value.keys()
        #     languages.sort()
        #     for language in languages:
        #         ws_string.write(row, index, wording_value_obj.language_value[language])
        #         index += 1
        #     row += 1
        #
        # wb.save(self.file_path)


if __name__ == '__main__':
    excel_option = ExcelOptions('/home/roy/tmp/Output.xlsx')
    print len(excel_option.read_records())
