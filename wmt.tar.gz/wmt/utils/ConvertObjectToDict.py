# -*- coding:utf-8 -*-
__author__ = 'changjie.fan'

""""""


def convert_to_dict(obj):
    """object对象转换成Dict对象"""

    obj_dict = {}
    obj_dict.update(obj.__dict__)
    return obj_dict


def convert_to_dicts(objs):
    """把对象列表转换成字典列表"""

    obj_arr = []

    for o in objs:
        obj_dict = {}
        obj_dict.update(o.__dict__)
        obj_arr.append(obj_dict)

    return obj_arr


def class_to_dict(obj):
    """把对象(单个对象、list、set)转出字典"""

    is_list = obj.__class__ == [].__class__
    is_set = obj.__class__ == set().__class__

    if is_list or is_set:
        obj_arr = []

        for o in obj:
            obj_dict = {}
            obj_dict.update(o.__dict__)
            obj_arr.append(obj_dict)

        return obj_arr
    else:
        obj_dict = {}
        obj_dict.update(obj.__dict__)
        return obj_dict
