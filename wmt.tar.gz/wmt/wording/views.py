# -*- coding:utf-8 -*-
__author__ = 'changjie.fan'

""""""
from flask import request, current_app, render_template
from flask.ext.login import login_required, current_user

from . import wording
from wmt import db
from models import Wording, CustomerWording, WordingLanguageValue