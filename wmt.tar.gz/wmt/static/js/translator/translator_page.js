//var editor;
var need_translate_wording_table;
var has_submitted_wording_table;


//submit local_manager translated value
function submit_translated_value(table_id) {
    var selected_rows = [];
    var has_error = false;
    var translated_value = '';
    $('#'+table_id+' td span').each(function(){
        if($(this).attr('class') && $(this).attr('class') == 'checked'){
            if(table_id == 'need_translate_wording') {
                translated_value = $($(this).parent().parent().parent()[0].lastChild)[0].innerText;
                var row_data = need_translate_wording_table.row($(this).parent().parent().parent()).data();
            }else if(table_id == 'need_validate_wording'){
                translated_value = $($(this).parent().parent().parent()[0].lastChild)[0].innerText;
                var row_data = need_validate_wording_table.row($(this).parent().parent().parent()).data();
            }
            if(translated_value != '') {
                selected_rows.push(row_data.DT_RowId);
            }else{
                bootbox.alert('This "' + row_data.module_key + '" wording has not translated');
                has_error = true;
            }
        }
    });

    if(!has_error) {
        if (selected_rows.length == 0) {
            bootbox.alert('Not selected Record');
        } else {
            showMask();
            $.ajax({
                type: 'POST',
                url:'/translate/translate_value_submit',
                data:{task_wording_id:selected_rows},
                success:function(){
                    window.location.reload();
                }
            });
        }
    }
}


jQuery(document).ready(function () {

    //editor = new $.fn.dataTable.Editor({
    //    ajax: "/local_manager/save_translated_value",
    //    table: "#need_translate_wording",
    //    fields: [{
    //        name: "translated_value"
    //    }]
    //});
    //
    ////not assign to translator
    ////local manager edit it
    //if(!window.has_translator){
    //    // Activate an inline edit on click of a table cell
    //    $('#need_translate_wording').on('click', 'tbody td:last-child', function (e) {
    //        editor.inline(this);
    //    });
    //}

    need_translate_wording_table = $('#need_translate_wording').DataTable({
        //dom: "Bfrtip",
        "language": {
            "aria": {
                "sortAscending": ": activate to sort column ascending",
                "sortDescending": ": activate to sort column descending"
            },
            "emptyTable": "No data available in table",
            "info": "Showing _START_ to _END_ of _TOTAL_ records",
            "infoEmpty": "No records found",
            "infoFiltered": "(filtered1 from _MAX_ total records)",
            "lengthMenu": "Show _MENU_ records",
            "search": "Search:",
            "zeroRecords": "No matching records found",
            "paginate": {
                "previous": "Prev",
                "next": "Next",
                "last": "Last",
                "first": "First"
            }
        },
        "bServerSide": true, // save datatable state(pagination, sort, etc) in cookie.
        "bProcessing": true,
        ajax: {
            url: '/translate/need_translate_wording_data'
        },
        columns: [
            {
                'targets': 0,
                'searchable': false,
                'orderable': false,
                'render': function (data, type, full, meta) {
                    return '<div class="checker"><span ><input type="checkbox" checked></span></div>';
                }
            },
            {data: "no"},
            {data: "module_key"},
            {data: "description"},
            {data: "whole_string"},
            {data: "language"},
            {data: "translated_value"}
        ],
        "columnDefs": [
            {
                // The `data` parameter refers to the data for the cell (defined by the
                // `data` option, which defaults to the column being worked with, in
                // this case `data: 0`.
                "render": function ( data, type, row ) {
                    if(row.validate == -1) {
                        return '<font color="red">' + data + '</font>';
                    }else{
                        return data;
                    }
                },
                "targets": 6
            }
        ],
        "lengthMenu": [
            [5, 20, 100, 200, 500],
            [5, 20, 100, 200, 500] // change per page values here
        ],
        // set the initial value
        "pageLength": 5,
        "pagingType": "bootstrap_full_number"
    });

    has_submitted_wording_table = $('#has_submitted_wording').DataTable({
        //dom: "Bfrtip",
        "language": {
            "aria": {
                "sortAscending": ": activate to sort column ascending",
                "sortDescending": ": activate to sort column descending"
            },
            "emptyTable": "No data available in table",
            "info": "Showing _START_ to _END_ of _TOTAL_ records",
            "infoEmpty": "No records found",
            "infoFiltered": "(filtered1 from _MAX_ total records)",
            "lengthMenu": "Show _MENU_ records",
            "search": "Search:",
            "zeroRecords": "No matching records found",
            "paginate": {
                "previous": "Prev",
                "next": "Next",
                "last": "Last",
                "first": "First"
            }
        },
        "bServerSide": true, // save datatable state(pagination, sort, etc) in cookie.
        "bProcessing": true,
        ajax: {
            url: '/translate/has_submitted_wording_data',
            data: {
                'work_flow': function () {
                    return window.work_flow;
                }
            }
        },
        columns: [
            {data: "no"},
            {data: "module_key"},
            {data: "description"},
            {data: "whole_string"},
            {data: "language"},
            {data: "translated_value"},
            {data: "validate"}
        ],
        "lengthMenu": [
            [5, 20, 100, 200, 500],
            [5, 20, 100, 200, 500] // change per page values here
        ],
        // set the initial value
        "pageLength": 5,
        "pagingType": "bootstrap_full_number"
    });


    // select all
    $('#example-select-all').on('click', function () {
        var rows = need_translate_wording_table.rows({'search': 'applied'}).nodes();
        if ($('#example-select-all').parent().attr('class') == 'checked') {
            $('input[type="checkbox"]', rows).each(function () {
                $(this).parent().addClass("checked");
            });
        } else {
            $('input[type="checkbox"]', rows).each(function () {
                $(this).parent().removeClass("checked");
            });
        }
    });

    $('#need_translate_wording tbody').on('change', 'input[type="checkbox"]', function () {
        if (this.checked) {
            $('#example-select-all').parent().removeClass("checked");
            $(this).parent().removeClass("checked");
        } else {
            $(this).parent().addClass("checked");
        }
    });

    $('#need_translate_wording tbody').on('change', 'input[type="text"]', function () {
        var row_id = need_translate_wording_table.row($(this).parent().parent()).data()['DT_RowId'];
        $.ajax({
            url: '/local_manager/save_translated_value',
            type: 'POST',
            data: {'row_id': row_id, 'translated_value': $(this).val()},
            success: function () {

            }
        });
    });


    // 流程客户， 已submit字串的修改__START
    if(window.work_flow == 'True') {
        $('#has_submitted_wording tbody').on('dblclick', 'td', function () {
            var tdSeq = $(this).parent().find("td").index($(this)[0]);
            if (tdSeq != 5) {
                return;
            }
            var originalContent = $(this).text();

            $(this).addClass("cellEditing");
            $(this).html('<input type="text" style="margin-top: 10%;" value="' + originalContent + '" />');
            $(this).children().first().focus();

            $(this).children().first().keypress(function (e) {
                if (e.which == 13) {
                    var newContent = $(this).val();
                    $(this).parent().text(newContent);
                    $(this).parent().removeClass("cellEditing");
                }
            });

            $(this).children().first().blur(function () {
                $(this).parent().text(originalContent);
                $(this).parent().removeClass("cellEditing");
            });
        });

        $('#has_submitted_wording tbody').on('change', 'input[type="text"]', function () {
            var row_id = has_submitted_wording_table.row($(this).parent().parent()).data()['DT_RowId'];
            $.ajax({
                url: '/local_manager/update_submitted_translated_value',
                type: 'POST',
                data: {'row_id': row_id, 'translated_value': $(this).val()},
                success: function () {

                }
            });
        });
        // 已submit字串的修改__END
    }

    $('#need_translate_wording tbody').on('dblclick', 'td', function () {
        var tdSeq = $(this).parent().find("td").index($(this)[0]);
        if (tdSeq != 6) {
            return;
        }
        var originalContent = $(this).text();

        $(this).addClass("cellEditing");
        $(this).html('<input type="text" style="margin-top: 10%;" value="' + originalContent + '" />');
        $(this).children().first().focus();

        $(this).children().first().keypress(function (e) {
            if (e.which == 13) {
                var newContent = $(this).val();
                $(this).parent().text(newContent);
                $(this).parent().removeClass("cellEditing");
            }
        });

        $(this).children().first().blur(function () {
            $(this).parent().text(originalContent);
            $(this).parent().removeClass("cellEditing");
        });
    });

/**********************************************************************************************************/
    //Show/hide columns dynamically
    var tableColumnToggler = $('#sample_4_column_toggler');
    /* handle show/hide columns*/
    $('input[type="checkbox"]', tableColumnToggler).change(function () {
        /* Get the DataTables object again - this is not a recreation, just a get of the object */
        var iCol = parseInt($(this).attr("data-column"));
        var bVis = $('#need_translate_wording').dataTable().fnSettings().aoColumns[iCol].bVisible;
        $('#need_translate_wording').dataTable().fnSetColumnVis(iCol, (bVis ? false : true));
        var bVis2 = $('#has_translated_wording').dataTable().fnSettings().aoColumns[iCol].bVisible;
        $('#has_translated_wording').dataTable().fnSetColumnVis(iCol, (bVis2 ? false : true));
    });
});