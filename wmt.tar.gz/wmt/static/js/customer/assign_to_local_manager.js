
//单击事件处理
$('#need_assign_task_table tbody').on( 'dblclick', 'tr', function () {
    window.location.href = $SCRIPT_ROOT+'/customer_manager/sub_task_wording_page/' + $(this).attr('data');
});

$('#assign_task_select').on('change', function(){
    var local_manager_user = $("#assign_task_select option:selected").attr('data-lt');
    var agency_user = $("#assign_task_select option:selected").attr('data-tt');
    console.log(agency_user)
    $('#sub_task_own_select').html('');
    if (local_manager_user) {
        $("#sub_task_own_select").append('<optgroup label="Local Manager"><option value="local_manger#' +
            local_manager_user.split('#')[0] + '">' + local_manager_user.split('#')[1] + '</option></optgroup>');
    }


    if(agency_user){
        $("#sub_task_own_select").append('<optgroup label="Translate Agency"><option value="agency#' +
            agency_user.split('#')[0]+'">'+agency_user.split('#')[1]+'</option></optgroup>');
    }
});


//取消任务
function cancel_sub_task(task_id, sub_task_id){

    bootbox.confirm("Are you sure?", function(result) {
       if(result){
           $.getJSON(
                $SCRIPT_ROOT+'/customer_manager/cancel_sub_task',
                {
                    task_id: task_id,
                    sub_task_id: sub_task_id,
                    status: status
                },
                function(data){

                }
           );
       }
    });
}
