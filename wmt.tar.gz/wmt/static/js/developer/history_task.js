
function table_init() {
    var task_table = $('#task_table').DataTable({
        "language": {
            "aria": {
                "sortAscending": ": activate to sort column ascending",
                "sortDescending": ": activate to sort column descending"
            },
            "emptyTable": "No data available in table",
            "info": "Showing _START_ to _END_ of _TOTAL_ records",
            "infoEmpty": "No records found",
            "infoFiltered": "(filtered1 from _MAX_ total records)",
            "lengthMenu": "Show _MENU_ records",
            "search": "Search:",
            "zeroRecords": "No matching records found",
            "paginate": {
                "previous": "Prev",
                "next": "Next",
                "last": "Last",
                "first": "First"
            }
        },
        "bFilter": false,
        "bServerSide": true, // save datatable state(pagination, sort, etc) in cookie.
        "bProcessing": true,
        "ajax": {
            url: '/developer/history_task_data',
            data: {
                'customer_id': function () {
                    return window.customer_id;
                },
                'project_id': function () {
                    return window.project_id;
                },
                'option_date': function () {
                    return window.option_date;
                },
                'from_date': function () {
                    return window.from_date;
                },
                'to_date': function () {
                    return window.to_date;
                }
            },
        },
        "columns":[
            {"data": 'index'},
            {"data": 'task_name'},
            {"data": 'customer_name'},
            {"data": 'status'},
            {"data": 'create_time'},
            {"data": 'submit_time'},
            {"data": 'export_time'},
            {"data": 'creator'},
            {"data": ''}
        ],
        "columnDefs":[{
            "targets": -1,
            "data": null,
            "defaultContent": "<button class='btn btn-primary'>export</button>"
        }],
        "lengthMenu": [
            [10, 50, 200],
            [10, 50, 200] // change per page values here
        ],
        // set the initial value
        "pageLength": 10,
        "pagingType": "bootstrap_full_number"
    });
    return task_table;
}

var customer_id;
var project_id;
var option_date;
var from_date;
var to_date;

var task_table = table_init();
function filter_ajax(){
    customer_id = $("#customer").val();
    project_id = $("#project").val();
    option_date = $("#option_date").val();
    from_date = $("#from_date").val();
    to_date = $("#to_date").val();

    if (task_table) {
        task_table.ajax.reload();
    } else {
        task_table = table_init();
    }
}

$('#task_table tbody').on( 'click', 'td', function () {
    var tdSeq = $(this).parent().find("td").index($(this)[0]);
    if(tdSeq == 8){
        window.location.href=$SCRIPT_ROOT + '/developer/export_task/?task_id='+task_table.row($(this).parent()).data().task_id;
    }else {
        window.location.href = $SCRIPT_ROOT + '/developer/sub_task_page/' + task_table.row($(this).parent()).data().task_id;
    }
});

$("#task_table tr").live({
    mouseover:function(){
        $(this).css("cursor","pointer");
    }
});