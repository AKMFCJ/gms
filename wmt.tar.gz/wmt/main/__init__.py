# -*- coding:utf-8 -*-
__author__ = 'changjie.fan'

"""系统主入口"""
from flask import Blueprint

main = Blueprint('main', __name__)
from . import views
