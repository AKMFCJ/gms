#!/usr/bin/env python
# -*- coding:utf-8 -*-

__author__ = 'changjie.fan'

"""
基于flask-script扩展的管理入口
"""

import os
import sys

reload(sys)
sys.setdefaultencoding('utf-8')


COV = None

if os.environ.get('WMT_COVERAGE'):
    import coverage
    COV = coverage.coverage(branch=True, include='wmt/*')
    COV.start()

if os.path.exists('.env'):
    print 'Importing environment from env...'
    for line in open('.env'):
        var = line.strip().stplit('=')
        if len(var) == 2:
            os.environ[var[0]] = var[1]

from wmt import create_app, db

from wmt.auth.models import Role, User

from flask.ext.script import Manager, Shell
from flask.ext.migrate import Migrate, MigrateCommand

app = create_app(os.getenv('WMT') or 'default')
manager = Manager(app)
migrate = Migrate(app, db)


def make_shell_context():
    return dict(app=app, db=db, User=User, Role=Role)

manager.add_command("shell", Shell(make_context=make_shell_context))
manager.add_command('db', MigrateCommand)


@manager.command
def test(coverage=False):
    """执行单元测试"""

    if coverage and os.environ.get('WMT_COVERAGE'):
        os.environ['WMT_COVERAGE'] = '1'
        os.execvp(sys.executable, [sys.executable] + sys.argv)

    import unittest
    tests = unittest.TestLoader.discover('tests')
    unittest.TextTestResult(verbosity=2).run(tests)
    if COV:
        COV.stop()
        COV.start()
        print 'Coverage Summary:'
        COV.report()
        base_dir = os.path.abspath(os.path.dirname(__file__))
        cov_dir = os.path.join(base_dir, 'tmp/coverage')
        COV.html_report(directory=cov_dir)
        print 'HTML version: file://%s/index.html' % cov_dir
        COV.erase()


@manager.command
def profile(length=25, profile_dir=None):
    """
    Start the application under the code profiler.
    在代码分析器中运行应用
    """
    from werkzeug.contrib.profiler import ProfilerMiddleware
    app.wsgi_app = ProfilerMiddleware(app.wsgi_app, restrictions=[length], profile_dir=profile_dir)
    app.run()


@manager.command
def deploy():
    """执行部署任务"""
    from flask.ext.migrate import upgrade

    upgrade()


if __name__ == '__main__':
    manager.run()


