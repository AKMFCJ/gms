# -*- coding:utf-8 -*-
__author__ = 'changjie.fan'

"""字符串模块的蓝图"""
from flask import Blueprint

wording = Blueprint('wording', __name__)
from . import views
