# -*- coding:utf-8 -*-
__author__ = 'changjie.fan'

""""""
from datetime import datetime

from wmt import db
from wmt.customer.models import Customer, Translator, Language


class Wording(db.Model):
    """字串总表"""

    __tablename__ = 'wording'

    id = db.Column(db.Integer, primary_key=True)
    # strings.xml文件的path加上字符串的name 作为唯一的标识
    abs_path = db.Column(db.String(500))
    # root path路径android之后的加上 relative path
    path = db.Column(db.String(500))
    # 要翻译的字符串
    name = db.Column(db.String(200))
    description = db.Column(db.String(500))
    sub_description = db.Column(db.String(500))
    whole_string = db.Column(db.String(500))
    # 字符串的原始长度
    size = db.Column(db.Integer)
    # 备注
    note = db.Column(db.String(500))

    def __init__(self, path=None, string_type=None, attribute_type=None, attribute_value=None, description=None,
                 recommend_string=None, whole_string=None, note=None):
        self.path = path
        self.string_type = string_type
        self.attribute_type = attribute_type
        self.attribute_value = attribute_value
        self.description = description
        self.recommend_string = recommend_string
        self.whole_string = whole_string

    def __repr__(self):
        return '<Wording %r>' % self.path


class CustomerWording(db.Model):
    """客户字符串表"""

    __tablename__ = 'customer_wording'

    id = db.Column(db.Integer, primary_key=True)
    wording_id = db.Column(db.Integer, db.ForeignKey('wording.id'))
    wording = db.relationship('Wording', backref=db.backref('customer_wording', order_by=id))
    customer_id = db.Column(db.Integer, db.ForeignKey('customer.id'))
    customer = db.relationship('Customer', backref=db.backref('customer_wording', order_by=id))
    # 字符串状态0表示新加入翻译中 1表示已翻译 2表示已废弃
    status = db.Column(db.Integer, default=0)

    def __repr__(self):
        return '<CustomerWording %r>' % self.customer.name


class WordingLanguageValue(db.Model):
    """客户字符串各语言翻译结果"""

    __tablename__ = 'customer_wording_language_value'

    id = db.Column(db.Integer, primary_key=True)

    # 所属的客户，同一个字符串相同的语言在不同的客户下，可能有不同的翻译
    customer_wording_id = db.Column(db.Integer, db.ForeignKey('customer_wording.id'))
    customer_wording = db.relationship('CustomerWording', backref=db.backref('wording_language_value', order_by=id))

    # 翻译结果
    translated_value = db.Column(db.String(500))
    # 字符串的长度
    size = db.Column(db.Integer)

    # 最近翻译的时间
    translated_time = db.Column(db.DateTime, default=datetime.now())

    # 本地翻译的语言
    language_id = db.Column(db.Integer, db.ForeignKey('wmt_language.id'))
    language = db.relationship('Language', backref=db.backref('wording_language_value', order_by=id))

    # 最新的翻译是由哪个字任务完成的
    sub_task_id = db.Column(db.Integer, db.ForeignKey('sub_task.id'))
    sub_task = db.relationship('SubTask', backref=db.backref('wording_language_value', order_by=id))

    def __repr__(self):
        return '<WordingLanguageValue %r>' % self.translated_value


class WordingLink(db.Model):
    """字符串的关联，已翻译结果是否相同判断两个字串是否可以做关联"""

    __tablename__ = 'wording_link'

    id = db.Column(db.Integer, primary_key=True)
    from_wording_id = db.Column(db.Integer, db.ForeignKey('customer_wording_language_value.id'))
    from_wording = db.relationship('WordingLanguageValue', backref=db.backref('wording_link_from', lazy='dynamic'),
                                   foreign_keys='WordingLink.from_wording_id')
    to_wording_id = db.Column(db.Integer, db.ForeignKey('customer_wording_language_value.id'))
    to_wording = db.relationship('WordingLanguageValue', backref=db.backref('wording_link_to', lazy='dynamic'),
                                 foreign_keys='WordingLink.to_wording_id')

    def __repr__(self):
        return '<WordingLink %r>' % self.id
