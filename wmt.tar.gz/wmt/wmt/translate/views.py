# -*- coding:utf-8 -*-
__author__ = 'changjie.fan'

""""""
import os
from datetime import datetime
import simplejson as json

from flask import url_for, render_template, current_app, request, session

from flask.ext.login import login_required, current_user
from flask.ext.mail import Mail, Message

from wmt import db, mail
from . import translate

from wmt.task.models import SubTask, SubTaskCustomerWording
from wmt.customer.models import Translator, Customer
from wmt.wording.models import WordingLanguageValue


class LanguageTask:
    def __init__(self, language, tasks):
        self.language = language
        self.tasks = tasks


@translate.route('/translate_page')
@login_required
def translate_page():
    """翻译者的首页"""

    session['breadcrumbs'] = [session['breadcrumbs'][0]]
    session['breadcrumbs'].append({'text': 'Need Translate', 'url': url_for('translate.translate_page')})
    session['menu_path'] = ['Translate', 'Need Translate']

    return render_template('/translator/translator_page.html')


@translate.route('/need_translate_wording_data', methods=['GET', 'POST'])
@login_required
def need_translate_wording_data():
    """获取翻译者指定语言的所欲任务的待翻译字串"""

    start = int(request.args.get('start', 0))
    length = int(request.args.get('length', 5))
    search = request.args.get('search[value]', '')

    translator = Translator.query.filter(Translator.id == current_user.id).first()
    if translator.customer and not translator.customer.work_flow:
        wording_sql = "SELECT sub_w.sub_task_id, sub_w.customer_wording_id, wording.path, wording.name, " \
                      "wording.description, wording.whole_string, wmt_language.name, sub_w.translated_value, " \
                      "sub_w.validate FROM sub_task JOIN " \
                      "sub_task_customer_wording as sub_w ON sub_task.id=sub_w.sub_task_id JOIN customer_wording as c_w " \
                      "ON sub_w.customer_wording_id=c_w.id JOIN wording ON c_w.wording_id=wording.id JOIN wmt_language " \
                      "ON wmt_language.id=sub_task.language_id WHERE sub_task.status=0 AND " \
                      "sub_w.validate=0 AND sub_task.translator_id={0}".format(current_user.id)
    else:
        wording_sql = "SELECT sub_w.sub_task_id, sub_w.customer_wording_id, wording.path, wording.name, " \
                      "wording.description, wording.whole_string, wmt_language.name, sub_w.translated_value, " \
                      "sub_w.validate FROM sub_task JOIN " \
                      "sub_task_customer_wording as sub_w ON sub_task.id=sub_w.sub_task_id JOIN customer_wording as c_w " \
                      "ON sub_w.customer_wording_id=c_w.id JOIN wording ON c_w.wording_id=wording.id JOIN wmt_language " \
                      "ON wmt_language.id=sub_task.language_id WHERE sub_task.status=2 AND " \
                      "sub_w.validate IN(-1, 0) AND sub_task.translator_id={0}".format(current_user.id)

    if search:
        wording_sql += ' AND (wording.whole_string like "%%{0}%%" or sub_w.translated_value like "%%{1}%%")'.format(search, search)

    wording_sql += ' order by sub_task.create_time'

    current_app.logger.info(wording_sql)
    wordings = db.engine.execute(wording_sql).fetchall()
    index = 1
    result = []
    for record in wordings[start:start+length]:
        result.append({
            'DT_RowId': 'row_{0}_{1}'.format(record[0], record[1]),
            'no': index,
            'module_key': '{0}@{1}'.format(os.path.basename(record[2].split('/res/')[0]), record[3]),
            'description': record[4],
            'whole_string': record[5],
            'language': record[6],
            'translated_value': record[7],
            'validate': record[8]
        })
        index += 1

    return '{"recordsTotal": %s ,"recordsFiltered": %s,"data":%s}' % (len(wordings), len(wordings), json.dumps(result))


@translate.route('/translate_value_submit', methods=['GET', 'POST'])
@login_required
def translate_value_submit():
    """翻译数据的提交"""

    translator = Translator.query.filter(Translator.id == current_user.id).first()
    if translator:
        work_flow = translator.customer.work_flow
    else:
        work_flow = False

    # 走流程
    if work_flow:
        all_id = request.form.getlist('task_wording_id[]')
        # 本次提交中涉及到的任务，主要用于判断任务的所有字串是否都已翻译完成，
        # 翻译完成的就邮件通知对应语言的local manger对翻译结果进行验证
        all_sub_task_ids = []
        other_sub_task_list = []

        for sub_task_wording_id in all_id:
            sub_task_id = sub_task_wording_id.split('_')[1]
            if sub_task_id not in all_sub_task_ids:
                all_sub_task_ids.append(sub_task_id)
            customer_wording_id = sub_task_wording_id.split('_')[2]
            sub_task_wording = SubTaskCustomerWording.query.filter(
                db.and_(SubTaskCustomerWording.sub_task_id == sub_task_id,
                        SubTaskCustomerWording.customer_wording_id == customer_wording_id)).first()
            sub_task_wording.has_translated = True
            sub_task_wording.validate = 1
            sub_task_wording.submitted_time = datetime.now()

            # 当前字串所属子任务
            sub_task = SubTask.query.filter(SubTask.id == sub_task_id).first()

            # 判断是否有其他子任务中包含了此相同语言的相同字串，避免重复翻译
            other_task_wordings = SubTaskCustomerWording.query.join(SubTask).filter(
                db.and_(SubTaskCustomerWording.sub_task_id != sub_task_id,
                        SubTaskCustomerWording.customer_wording_id == customer_wording_id,
                        SubTaskCustomerWording.validate.in_([-1, 0, 1]),
                        SubTask.language_id == sub_task.language_id)).all()
            for other_task_wording in other_task_wordings:
                other_sub_task = SubTask.query.filter(SubTask.id == other_task_wording.sub_task_id).first()
                if other_sub_task:
                    other_task_wording.has_translated = True
                    other_task_wording.validate = 1
                    other_task_wording.translated_value = sub_task_wording.translated_value
                    other_task_wording.submitted_time = datetime.now()
                    db.session.add(other_task_wording)
                    if other_sub_task not in other_sub_task_list:
                        other_sub_task_list.append(other_sub_task)

            db.session.add(sub_task_wording)
        db.session.commit()

        # 检查其他包含同样字串需要翻译相同语言的子任务是否都已翻译完成
        for other_sub_task in other_sub_task_list:
            sub_customer_wording_count = SubTaskCustomerWording.query.filter(
                db.and_(SubTaskCustomerWording.sub_task_id == other_sub_task.id,
                        SubTaskCustomerWording.has_translated == 0)).count()

            if sub_customer_wording_count > 0:
                other_sub_task.progress = int(float(len(other_sub_task.customer_wording)-sub_customer_wording_count)/len(other_sub_task.customer_wording)*100)
                db.session.add(other_sub_task)
            else:
                other_sub_task.submit_time = datetime.now()
                other_sub_task.progress = 100
                other_sub_task.status = 3
                db.session.add(other_sub_task)

                # 已经测试过，邮件可以正常发出
                msg = Message(
                    '[WMT]Task %s has translated complete' % other_sub_task.name,
                    sender='Tinno@tinn.com',
                    recipients=[other_sub_task.local_manager.email]
                )
                msg.body = "Please validate this task"
                mail.send(msg)

        #  检查子任务所有字串是否都翻译完成
        for sub_task_id in all_sub_task_ids:
            sub_customer_wording_count = SubTaskCustomerWording.query.filter(
                db.and_(SubTaskCustomerWording.sub_task_id == sub_task_id,
                        SubTaskCustomerWording.has_translated == 0)).count()

            sub_task = SubTask.query.filter(SubTask.id == sub_task_id).first()
            if sub_customer_wording_count > 0:
                sub_task.progress = int(float(len(sub_task.customer_wording)-sub_customer_wording_count)/len(sub_task.customer_wording)*100)
                db.session.add(sub_task)
            else:
                sub_task.submit_time = datetime.now()
                sub_task.progress = 100
                sub_task.status = 3
                db.session.add(sub_task)

                # 已经测试过，邮件可以正常发出
                msg = Message(
                    '[WMT]Task %s has translated complete' % sub_task.name,
                    sender='Tinno@tinn.com',
                    recipients=[sub_task.local_manager.email]
                )
                msg.body = "Please validate this task"
                mail.send(msg)

        db.session.commit()
    else:
        all_id = request.form.getlist('task_wording_id[]')
        # 本次提交中涉及到的任务，主要用于判断任务的所有字串是否都已翻译完成，
        all_sub_task_ids = []
        other_sub_task_list = []

        for sub_task_wording_id in all_id:
            # 当前字串所属子任务
            sub_task_id = sub_task_wording_id.split('_')[1]
            sub_task = SubTask.query.filter(SubTask.id == sub_task_id).first()

            if sub_task_id not in all_sub_task_ids:
                all_sub_task_ids.append(sub_task_id)
            customer_wording_id = sub_task_wording_id.split('_')[2]
            sub_task_wording = SubTaskCustomerWording.query.filter(
                db.and_(SubTaskCustomerWording.sub_task_id == sub_task_id,
                        SubTaskCustomerWording.customer_wording_id == customer_wording_id)).first()
            sub_task_wording.has_translated = True
            sub_task_wording.validate = 2
            sub_task_wording.submitted_time = datetime.now()

            # 更新或添加客户字串对应语言的值
            wording_language_value = WordingLanguageValue.query.filter(
                db.and_(WordingLanguageValue.customer_wording_id == customer_wording_id,
                        WordingLanguageValue.language_id == sub_task.language_id)).first()
            if wording_language_value:
                wording_language_value.translated_value = sub_task_wording.translated_value
                wording_language_value.translated_time = datetime.now()
                wording_language_value.size = len(sub_task_wording.translated_value)
                wording_language_value.sub_task = sub_task
                db.session.add(wording_language_value)
            else:
                wording_language_value = WordingLanguageValue()
                wording_language_value.translated_value = sub_task_wording.translated_value
                wording_language_value.translated_time = datetime.now()
                wording_language_value.sub_task = sub_task
                wording_language_value.language_id = sub_task.language_id
                wording_language_value.customer_wording_id = customer_wording_id
                wording_language_value.size = len(sub_task_wording.translated_value)
                db.session.add(wording_language_value)
                db.session.commit()

            # 判断是否有其他子任务中包含了此相同语言的相同字串，避免重复翻译
            other_task_wordings = SubTaskCustomerWording.query.join(SubTask).filter(
                db.and_(SubTaskCustomerWording.sub_task_id != sub_task_id,
                        SubTaskCustomerWording.customer_wording_id == customer_wording_id,
                        SubTaskCustomerWording.validate.in_([-1, 0, 1]),
                        SubTask.language_id == sub_task.language_id)).all()
            for other_task_wording in other_task_wordings:
                other_sub_task = SubTask.query.filter(SubTask.id == other_task_wording.sub_task_id).first()
                if other_sub_task:
                    other_task_wording.has_translated = True
                    other_task_wording.validate = 2
                    other_task_wording.translated_value = sub_task_wording.translated_value
                    other_task_wording.submitted_time = datetime.now()
                    db.session.add(other_task_wording)
                    if other_sub_task not in other_sub_task_list:
                        other_sub_task_list.append(other_sub_task)

            db.session.add(sub_task_wording)
        db.session.commit()

        # 检查其他包含同样字串需要翻译相同语言的子任务是否都已翻译完成
        for other_sub_task in other_sub_task_list:
            sub_customer_wording_count = SubTaskCustomerWording.query.filter(
                db.and_(SubTaskCustomerWording.sub_task_id == other_sub_task.id,
                        SubTaskCustomerWording.has_translated == 0)).count()

            if sub_customer_wording_count > 0:
                other_sub_task.progress = int(
                    float(len(other_sub_task.customer_wording) - sub_customer_wording_count) / len(
                        other_sub_task.customer_wording) * 100)
                db.session.add(other_sub_task)
            else:
                other_sub_task.submit_time = datetime.now()
                other_sub_task.progress = 100
                other_sub_task.status = 4
                db.session.add(other_sub_task)
                # 已经测试过，邮件可以正常发出
                msg = Message(
                    '[WMT]Task %s has translated complete' % other_sub_task.name,
                    sender='Tinno@tinn.com',
                    recipients=[sub_task.task.creator.email]
                )
                msg.body = "This SubTask has translated!"
                mail.send(msg)
            db.session.commit()

            # 检查主任务是否翻译结束
            primary_task = other_sub_task.task
            all_incomplete_sub_task_count = SubTask.query.filter(
                db.and_(SubTask.task_id == other_sub_task.task_id, SubTask.status == 0)).count()

            if all_incomplete_sub_task_count > 0:
                all_sub_task = SubTask.query.filter_by(task_id=other_sub_task.task_id).all()
                primary_task.progress = int(
                    float(len(all_sub_task) - all_incomplete_sub_task_count) / len(all_sub_task) * 100)
            else:
                primary_task.submit_time = datetime.now()
                primary_task.status = 4
                primary_task.progress = 100

                db.session.add(primary_task)
                db.session.commit()

                # 已经测试过，邮件可以正常发出
                msg = Message(
                    '[WMT]%s translated complete' % primary_task.name,
                    sender='Tinno@tinn.com',
                    recipients=[primary_task.creator.email]
                )
                msg.body = "All Sub task has translated"
                mail.send(msg)

        # 检查子任务所有字串是否都翻译完成
        for sub_task_id in all_sub_task_ids:
            sub_customer_wording_count = SubTaskCustomerWording.query.filter(
                db.and_(SubTaskCustomerWording.sub_task_id == sub_task_id,
                        SubTaskCustomerWording.has_translated == 0)).count()

            sub_task = SubTask.query.filter(SubTask.id == sub_task_id).first()
            if sub_customer_wording_count > 0:
                sub_task.progress = int(float(len(sub_task.customer_wording) - sub_customer_wording_count) / len(
                    sub_task.customer_wording) * 100)
                db.session.add(sub_task)
            else:
                sub_task.submit_time = datetime.now()
                sub_task.progress = 100
                sub_task.status = 4
                db.session.add(sub_task)

                # 已经测试过，邮件可以正常发出
                msg = Message(
                    '[WMT]Task %s has translated complete' % sub_task.name,
                    sender='Tinno@tinn.com',
                    recipients=[sub_task.task.creator.email]
                )
                msg.body = "This SubTask has translated!"
                mail.send(msg)
            db.session.commit()

            # 检查主任务是否翻译结束
            primary_task = sub_task.task
            all_incomplete_sub_task_count = SubTask.query.filter(
                db.and_(SubTask.task_id == sub_task.task_id, SubTask.status == 0)).count()

            if all_incomplete_sub_task_count > 0:
                all_sub_task = SubTask.query.filter_by(task_id=sub_task.task_id).all()
                primary_task.progress = int(
                    float(len(all_sub_task) - all_incomplete_sub_task_count) / len(all_sub_task) * 100)
            else:
                primary_task.submit_time = datetime.now()
                primary_task.status = 4
                primary_task.progress = 100

                db.session.add(primary_task)
                db.session.commit()

                # 已经测试过，邮件可以正常发出
                msg = Message(
                    '[WMT]%s translated complete' % primary_task.name,
                    sender='Tinno@tinn.com',
                    recipients=[primary_task.creator.email]
                )
                msg.body = "All Sub task has translated"
                mail.send(msg)

    return '{"success": true}'


@translate.route('/has_submitted_wording_data', methods=['GET', 'POST'])
@login_required
def has_submitted_wording_data():
    """已经翻译提交的字串数据"""

    start = int(request.args.get('start', 0))
    length = int(request.args.get('length', 5))
    search = request.args.get('search[value]', '')

    wording_sql = "SELECT sub_w.sub_task_id, sub_w.customer_wording_id, wording.path, wording.name, " \
                  "wording.description, wording.whole_string, wmt_language.name, sub_w.translated_value, " \
                  "sub_w.validate FROM sub_task JOIN " \
                  "sub_task_customer_wording as sub_w ON sub_task.id=sub_w.sub_task_id JOIN customer_wording as c_w " \
                  "ON sub_w.customer_wording_id=c_w.id JOIN wording ON c_w.wording_id=wording.id JOIN wmt_language " \
                  "ON wmt_language.id=sub_task.language_id WHERE " \
                  "sub_w.validate=1 AND sub_task.translator_id={0}".format(current_user.id)

    if search:
        wording_sql += ' AND (wording.whole_string like "%%{0}%%" or sub_w.translated_value like "%%{1}%%")'.format(search, search)

    wording_sql += ' order by sub_w.submitted_time DESC'

    current_app.logger.info(wording_sql)
    wordings = db.engine.execute(wording_sql).fetchall()
    index = 1
    result = []
    for record in wordings[start:start+length]:
        if record[8] == 1:
            status = 'Submitted'
        elif record[8] == 2:
            status = 'validated'

        result.append({
            'DT_RowId': 'row_{0}_{1}'.format(record[0], record[1]),
            'no': index,
            'module_key': '{0}@{1}'.format(os.path.basename(record[2].split('/res/')[0]), record[3]),
            'description': record[4],
            'whole_string': record[5],
            'language': record[6],
            'translated_value': record[7],
            'validate': status
        })
        index += 1

    return '{"recordsTotal": %s ,"recordsFiltered": %s,"data":%s}' % (len(wordings), len(wordings), json.dumps(result))
