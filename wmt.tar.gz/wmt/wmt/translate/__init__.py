# -*- coding:utf-8 -*-
__author__ = 'changjie.fan'

""""""
from flask import Blueprint

translate = Blueprint('translate', __name__)
from . import views
