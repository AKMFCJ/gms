# -*- coding:utf-8 -*-
__author__ = 'changjie.fan'

"""
数据库操作
"""


class DBOption:
    def __init__(self, db_url, db_type='sqlite'):
        self.db_type = db_type
        self.db_url = db_url
        self.conn = None
        self.cursor = None

    def db_connect(self):
        """
        数据库连接、获取游标
        """
        if self.db_type == 'sqlite':
            import sqlite3
            self.conn = sqlite3.connect(self.db_url)
            self.cursor = self.conn.cursor()
        else:
            from MySQLdb import connect
            self.conn = connect(host=self.db_url['host'], db=self.db_url['db_name'], user=self.db_url['username'],
                                passwd=self.db_url['password'], charset='utf8')
            self.cursor = self.conn.cursor()

    def fetch_one(self, sql):
        """返回第一条结果"""
        print sql
        self.cursor.execute(sql)
        r = self.cursor.fetchall()
        if len(r) > 0:
            return [r[0][e]for e in range(len(r[0]))]
        return []

    def fetch_all(self, sql):
        """返回第一条结果"""

        print sql
        self.cursor.execute(sql)
        r = self.cursor.fetchall()
        if len(r) > 0:
            return [[r[p][e] for e in range(len(r[p]))] for p in range(len(r))]
        return []

    def insert_one(self, sql):
        """
        插入一条记录
        """
        print sql
        self.cursor.execute(sql)
        return self.conn.commit()

    def insert_all(self, sql, data):
        """
        插入多条纪录
        """
        print sql
        self.cursor.executemany(sql, data)
        return self.conn.commit()

    def close(self):
        """
        关闭数据库连接
        """

        self.cursor.close()
        self.conn.close()
