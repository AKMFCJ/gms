# -*- coding:utf-8 -*-
__author__ = 'changjie.fan'

"""定义客户local manager模块的蓝图"""
from flask import Blueprint

local_manager = Blueprint('local_manager', __name__)
from . import views
