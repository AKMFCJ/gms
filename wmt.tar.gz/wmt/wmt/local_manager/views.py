# -*- coding:utf-8 -*-
__author__ = 'changjie.fan'

""""""
import os
from datetime import datetime
import simplejson as json

from flask import render_template, redirect, url_for, request, flash, current_app, session
from flask.ext.login import login_required, current_user
from flask.ext.mail import Message

from wmt import db, mail
from . import local_manager
from wmt.auth.models import User, Role
from wmt.customer.models import CustomerManager, Translator, Customer, Language, TranslateAgency
from wmt.task.models import Task, SubTask, SubTaskCustomerWording
from wmt.project.models import Project
from wmt.wording.models import WordingLanguageValue, CustomerWording


@local_manager.route('/my_task')
@login_required
def my_task():
    """local manager的任务"""

    session['breadcrumbs'] = [session['breadcrumbs'][0]]
    session['breadcrumbs'].append({'text': 'MyTask', 'url': url_for('local_manager.my_task')})
    session['menu_path'] = ['Task Manager', 'MyTask']

    customer = CustomerManager.query.filter_by(id=current_user.id).first().customer

    # 正在翻译的、未分配的、翻译完成未确认的任务
    tasks = SubTask.query.join(Task.project).filter(
        db.and_(SubTask.local_manager_id == current_user.id,
                Project.customer == customer,
                SubTask.status.in_([1, 2, 3]))).all()
    for task in tasks:
        if task.status == 0:
            task.status_name = 'need assign'
        elif task.status == 1:
            task.status_name = 'assign to local manager'
        elif task.status == 2:
            task.status_name = 'translating'
        elif task.status == 3:
            task.status_name = 'need validate'
        elif task.status == 4:
            task.status_name = 'need export'

    return render_template('/local_manager/my_task_page.html', all_task=tasks)


@local_manager.route('/assign_task/<int:sub_task_id>', methods=['GET', 'POST'])
@login_required
def assign_task(sub_task_id):
    """任务分配给翻译者"""

    if request.method == 'POST':
        sub_task = SubTask.query.filter_by(id=sub_task_id).first()
        sub_task.translator_id = int(request.form.get('translator'))
        sub_task.status = 2
        db.session.add(sub_task)
        db.session.commit()
        return redirect(url_for('local_manager.my_task'))
    else:
        for breadcrumb in session['breadcrumbs']:
            if 'SubTask Info' == breadcrumb['text']:
                break
        else:
            session['breadcrumbs'].append({'text': 'SubTask Info',
                                           'url': url_for('local_manager.sub_task_wording_page', sub_task_id=sub_task_id)})

        sub_task = SubTask.query.filter_by(id=sub_task_id).first()

        customer = CustomerManager.query.filter_by(id=current_user.id).first().customer
        customer_all_translator = Translator.query.filter(db.and_(Translator.customer_id == customer.id,
                                                                  Translator.activate == True)).all()
        translators = []
        for translator in customer_all_translator:
            if not translator.translate_agency and sub_task.language in translator.language:
                translators.append(translator)

        if not translators:
            flash("You have not this {0} language's translator. "
                  "Please create a translator account for it".format(sub_task.language.name), 'info')

        return render_template('local_manager/sub_task_detail_info.html',
                               sub_task=sub_task, translators=translators, has_translator=False, from_assign=True)


@local_manager.route('/sub_task_wording_page/<int:sub_task_id>', methods=['GET', 'POST'])
@login_required
def sub_task_wording_page(sub_task_id):
    """子任务翻译和为翻译的字串页面"""

    for breadcrumb in session['breadcrumbs']:
        if 'SubTask Info' == breadcrumb['text']:
            break
    else:
        session['breadcrumbs'].append({'text': 'SubTask Info',
                                       'url': url_for('local_manager.sub_task_wording_page', sub_task_id=sub_task_id)})

    sub_task = SubTask.query.filter_by(id=sub_task_id).first()
    if sub_task.status == 2 and sub_task.translator:
        has_translator = True
    else:
        has_translator = False

    return render_template('local_manager/sub_task_detail_info.html', sub_task=sub_task, has_translator=has_translator)


@local_manager.route('/sub_task_need_translate_wording_data')
@login_required
def sub_task_need_translate_wording_data():
    """
    子任务中需要翻译的字串
    """

    start = int(request.args.get('start', 0))
    length = int(request.args.get('length', 5))
    sub_task_id = request.args.get('sub_task_id')
    search = request.args.get('search[value]')

    wording_sql = "SELECT sub_w.sub_task_id, sub_w.customer_wording_id, wording.path, wording.name, " \
                  "wording.description, wording.whole_string, sub_w.translated_value FROM sub_task JOIN " \
                  "sub_task_customer_wording as sub_w ON sub_task.id=sub_w.sub_task_id JOIN customer_wording as c_w " \
                  "ON sub_w.customer_wording_id=c_w.id JOIN wording ON c_w.wording_id=wording.id WHERE " \
                  "sub_w.has_translated=0 AND sub_task.id={0}".format(sub_task_id)

    if search:
        wording_sql += ' AND (wording.whole_string like "%%{0}%%" or sub_w.translated_value like "%%{1}%%")'.format(search, search)

    wordings = db.engine.execute(wording_sql).fetchall()
    index = start + 1
    result = []
    for record in wordings[start:start+length]:
        result.append({
            'DT_RowId': 'row_{0}_{1}'.format(record[0], record[1]),
            'no': index,
            'module_key': '{0}@{1}'.format(os.path.basename(record[2].split('/res/')[0]), record[3]),
            'description': record[4],
            'whole_string': record[5],
            'translated_value': record[6]
        })
        index += 1

    return '{"recordsTotal": %s ,"recordsFiltered": %s,"data":%s}' % (len(wordings), len(wordings),
                                                                      json.dumps(result))


@local_manager.route('/sub_task_has_translated_wording_data')
@login_required
def sub_task_has_translated_wording_data():
    """
    子任务中已经翻译过的字串
    """

    start = int(request.args.get('start', 0))
    length = int(request.args.get('length', 10))
    sub_task_id = request.args.get('sub_task_id')
    search = request.args.get('search[value]')

    wording_sql = "SELECT sub_w.sub_task_id, sub_w.customer_wording_id, wording.path, wording.name, " \
                  "wording.description, wording.whole_string, sub_w.translated_value FROM sub_task JOIN " \
                  "sub_task_customer_wording as sub_w ON sub_task.id=sub_w.sub_task_id JOIN customer_wording as c_w " \
                  "ON sub_w.customer_wording_id=c_w.id JOIN wording ON c_w.wording_id=wording.id WHERE " \
                  "sub_w.has_translated=1 AND sub_w.validate=2 AND sub_task.id={0}".format(sub_task_id)

    if search:
        wording_sql += ' AND (wording.whole_string like "%%{0}%%" or sub_w.translated_value like "%%{1}%%")'.format(
            search, search)

    wordings = db.engine.execute(wording_sql).fetchall()
    index = start + 1
    result = []
    for record in wordings[start:start+length]:
        result.append({
            'DT_RowId': 'row_{0}_{1}'.format(record[0], record[1]),
            'no': index,
            'module_key': '{0}@{1}'.format(os.path.basename(record[2].split('/res/')[0]), record[3]),
            'description': record[4],
            'whole_string': record[5],
            'translated_value': record[6]
        })
        index += 1

    return '{"recordsTotal": %s ,"recordsFiltered": %s,"data":%s}' % (len(wordings), len(wordings),
                                                                      json.dumps(result))


@local_manager.route('/save_translated_value', methods=['GET', 'POST'])
@login_required
def save_translated_value():
    """
    临时存储字串的值
    """

    row, sub_task_id, customer_wording_id = request.form.get('row_id').split('_')
    translated_value = request.form.get('translated_value')

    sub_task_wording = SubTaskCustomerWording.query.filter(
        db.and_(SubTaskCustomerWording.sub_task_id == sub_task_id,
                SubTaskCustomerWording.customer_wording_id == customer_wording_id)).first()
    sub_task_wording.translated_value = translated_value
    db.session.add(sub_task_wording)
    db.session.commit()

    wording_sql = "SELECT sub_w.sub_task_id, sub_w.customer_wording_id, wording.path, wording.name, " \
                  "wording.description, wording.whole_string, sub_w.translated_value FROM sub_task " \
                  "JOIN sub_task_customer_wording as sub_w ON sub_task.id=sub_w.sub_task_id JOIN " \
                  "customer_wording as c_w ON sub_w.customer_wording_id=c_w.id JOIN wording ON " \
                  "c_w.wording_id=wording.id WHERE sub_w.has_translated=0 AND sub_task.id={0} AND " \
                  "sub_w.customer_wording_id={1}".format(sub_task_id, customer_wording_id)

    current_app.logger.info(wording_sql)
    wordings = db.engine.execute(wording_sql).fetchall()

    index = 1
    result = []
    for record in wordings:
        result.append({
            'DT_RowId': 'row_{0}_{1}'.format(record[0], record[1]),
            'no': index,
            'module_key': '{0}@{1}'.format(os.path.basename(record[2].split('/res/')[0]), record[3]),
            'description': record[4],
            'whole_string': record[5],
            'translated_value': record[6]
        })
        index += 1

    return '{"data":%s}' % (json.dumps(result))


@local_manager.route('/update_submitted_translated_value', methods=['GET', 'POST'])
@login_required
def update_submitted_translated_value():
    """
    修改已经提交了的字串翻译值
    """

    row, sub_task_id, customer_wording_id = request.form.get('row_id').split('_')
    translated_value = request.form.get('translated_value')

    sub_task_wording = SubTaskCustomerWording.query.filter(
        db.and_(SubTaskCustomerWording.sub_task_id == sub_task_id,
                SubTaskCustomerWording.customer_wording_id == customer_wording_id)).first()
    sub_task_wording.translated_value = translated_value
    sub_task = SubTask.query.filter_by(id=sub_task_id).first()
    wording_language_value = WordingLanguageValue.query.filter(
        db.and_(WordingLanguageValue.customer_wording_id == customer_wording_id,
                WordingLanguageValue.language_id == sub_task.language_id)).first()
    if wording_language_value:
        wording_language_value.translated_value = translated_value
        wording_language_value.translated_time = datetime.now()
        db.session.add(wording_language_value)
    # else:
    #     wording_language_value = WordingLanguageValue()
    #     wording_language_value.sub_task_id = sub_task_id
    #     wording_language_value.customer_wording_id = customer_wording_id
    #     wording_language_value.language_id = sub_task.language_id
    #     wording_language_value.translated_value = translated_value
    #     wording_language_value.translated_time = datetime.now()

    db.session.add(sub_task_wording)
    db.session.commit()

    wording_sql = "SELECT sub_w.sub_task_id, sub_w.customer_wording_id, wording.path, wording.name, " \
                  "wording.description, wording.whole_string, sub_w.translated_value FROM sub_task " \
                  "JOIN sub_task_customer_wording as sub_w ON sub_task.id=sub_w.sub_task_id JOIN " \
                  "customer_wording as c_w ON sub_w.customer_wording_id=c_w.id JOIN wording ON " \
                  "c_w.wording_id=wording.id WHERE sub_w.has_translated=0 AND sub_task.id={0} AND " \
                  "sub_w.customer_wording_id={1}".format(sub_task_id, customer_wording_id)

    current_app.logger.info(wording_sql)
    wordings = db.engine.execute(wording_sql).fetchall()

    index = 1
    result = []
    for record in wordings:
        result.append({
            'DT_RowId': 'row_{0}_{1}'.format(record[0], record[1]),
            'no': index,
            'module_key': '{0}@{1}'.format(os.path.basename(record[2].split('/res/')[0]), record[3]),
            'description': record[4],
            'whole_string': record[5],
            'translated_value': record[6]
        })
        index += 1

    return '{"data":%s}' % (json.dumps(result))


@local_manager.route('/commit_sub_task_wording', methods=['POST'])
@login_required
def commit_sub_task_wording():
    """提交翻译字串, 更新子任务状态, 客户字串的翻译值，主任务状态"""

    all_id = request.form.getlist('task_wording_id[]')

    for sub_task_wording_id in all_id:
        sub_task = SubTask.query.filter_by(id=sub_task_wording_id.split('_')[1]).first()
        customer_wording_id = sub_task_wording_id.split('_')[2]
        sub_task_wording = SubTaskCustomerWording.query.filter(
            db.and_(SubTaskCustomerWording.sub_task_id == sub_task.id,
                    SubTaskCustomerWording.customer_wording_id == customer_wording_id)).first()

        sub_task_wording.has_translated = True
        sub_task_wording.validate = 2
        sub_task_wording.validate_user_id = current_user.id
        db.session.add(sub_task_wording)
        # 更新或添加客户字串对应语言的值
        wording_language_value = WordingLanguageValue.query.filter(
            db.and_(WordingLanguageValue.customer_wording_id == customer_wording_id,
                    WordingLanguageValue.language_id == sub_task.language_id)).first()
        if wording_language_value:
            wording_language_value.translated_value = sub_task_wording.translated_value
            wording_language_value.translated_time = datetime.now()
            wording_language_value.size = len(sub_task_wording.translated_value)
            wording_language_value.sub_task = sub_task
            db.session.add(wording_language_value)
        else:
            wording_language_value = WordingLanguageValue()
            wording_language_value.translated_value = sub_task_wording.translated_value
            wording_language_value.translated_time = datetime.now()
            wording_language_value.sub_task = sub_task
            wording_language_value.language_id = sub_task.language_id
            wording_language_value.customer_wording_id = customer_wording_id
            wording_language_value.size = len(sub_task_wording.translated_value)
            db.session.add(wording_language_value)
            db.session.commit()

        # 判断是否有其他子任务中包含了此相同语言的相同字串，避免重复翻译
        # 先找出相同客户字符串的不同子任务
        other_task_wordings = SubTaskCustomerWording.query.join(SubTask).filter(
            db.and_(SubTaskCustomerWording.sub_task_id != sub_task.id,
                    SubTaskCustomerWording.customer_wording_id == customer_wording_id,
                    SubTaskCustomerWording.validate == 1,
                    SubTask.language_id == sub_task.language_id)).all()
        for other_sub_task_wording in other_task_wordings:
            # 从不同子任务中找出语言相同的子任务
            other_sub_task = SubTask.query.filter(SubTask.id == other_sub_task_wording.sub_task_id).first()
            other_sub_task_wording.has_translated = True
            other_sub_task_wording.validate = 2
            other_sub_task_wording.validate_user_id = current_user.id
            db.session.add(other_sub_task_wording)
            db.session.commit()

            #  检查其他子任务所有字串是否都翻译完成(验证通过)
            other_sub_customer_wording_count = SubTaskCustomerWording.query.filter(
                db.and_(SubTaskCustomerWording.sub_task_id == other_sub_task.id,
                        SubTaskCustomerWording.has_translated == 0)).count()

            if other_sub_customer_wording_count > 0:
                other_sub_task.progress = int(float(len(other_sub_task.customer_wording)-other_sub_customer_wording_count)/len(other_sub_task.customer_wording)*100)
                db.session.add(other_sub_task)
                db.session.commit()
            else:
                other_sub_task.submit_time = datetime.now()
                other_sub_task.progress = 100
                other_sub_task.status = 4
                db.session.add(other_sub_task)
                db.session.commit()

                # 检查主任务是否翻译结束
                other_primary_task = other_sub_task.task

                other_all_incomplete_sub_task_count = SubTask.query.filter(
                    db.and_(SubTask.task_id == other_sub_task.task_id, SubTask.status.in_((1, 2, 3)))).count()
                if other_all_incomplete_sub_task_count > 0:
                    other_all_sub_task = SubTask.query.filter_by(task_id=other_sub_task.task_id).all()
                    other_primary_task.progress = int(float(len(other_all_sub_task)-other_all_incomplete_sub_task_count)/len(other_all_sub_task)*100)
                else:
                    other_primary_task.submit_time = datetime.now()
                    other_primary_task.status = 4
                    other_primary_task.progress = 100
                    db.session.add(other_primary_task)
                    db.session.commit()

                    # 已经测试过，邮件可以正常发出
                    msg = Message(
                        '[WMT]%s translated complete' % other_primary_task.name,
                        sender='Tinno@tinn.com',
                        recipients=[other_primary_task.creator.email]
                    )
                    msg.body = "All Sub task has translated"
                    mail.send(msg)

        wording_language_value.customer_wording.status = 1
        db.session.add(wording_language_value.customer_wording)

    db.session.commit()

    #  检查子任务所有字串是否都翻译完成(验证通过)
    sub_customer_wording_count = SubTaskCustomerWording.query.filter(
        db.and_(SubTaskCustomerWording.sub_task_id == sub_task.id,
                SubTaskCustomerWording.has_translated == 0)).count()

    if sub_customer_wording_count > 0:
        sub_task.progress = int(float(len(sub_task.customer_wording)-sub_customer_wording_count)/len(sub_task.customer_wording)*100)
        db.session.add(sub_task)
        db.session.commit()
    else:
        sub_task.submit_time = datetime.now()
        sub_task.progress = 100
        sub_task.status = 4
        db.session.add(sub_task)
        db.session.commit()

        # 检查主任务是否翻译结束
        primary_task = sub_task.task

        all_incomplete_sub_task_count = SubTask.query.filter(
            db.and_(SubTask.task_id == sub_task.task_id, SubTask.status.in_((1, 2, 3)))).count()
        if all_incomplete_sub_task_count > 0:
            all_sub_task = SubTask.query.filter_by(task_id=sub_task.task_id).all()
            primary_task.progress = int(float(len(all_sub_task)-all_incomplete_sub_task_count)/len(all_sub_task)*100)
        else:
            primary_task.submit_time = datetime.now()
            primary_task.status = 4
            primary_task.progress = 100

            db.session.add(primary_task)
            db.session.commit()

            # 已经测试过，邮件可以正常发出
            msg = Message(
                '[WMT]%s translated complete' % primary_task.name,
                sender='Tinno@tinn.com',
                recipients=[primary_task.creator.email]
            )
            msg.body = "All Sub task has translated"
            mail.send(msg)

    flash('Wording Submit Success', 'info')
    return '{"result": true}'


@local_manager.route('/sub_task_need_validate_wording_data')
@login_required
def sub_task_need_validate_wording_data():
    """
    待验证字符串
    """

    start = int(request.args.get('start', 0))
    length = int(request.args.get('length', 10))
    sub_task_id = request.args.get('sub_task_id')
    search = request.args.get('search[value]')

    wording_sql = "SELECT sub_w.sub_task_id, sub_w.customer_wording_id, wording.path, wording.name, " \
                  "wording.description, wording.whole_string, sub_w.translated_value FROM sub_task JOIN " \
                  "sub_task_customer_wording as sub_w ON sub_task.id=sub_w.sub_task_id JOIN customer_wording as c_w " \
                  "ON sub_w.customer_wording_id=c_w.id JOIN wording ON c_w.wording_id=wording.id WHERE " \
                  "sub_w.has_translated=1 AND sub_w.validate=1 AND sub_task.id={0}".format(sub_task_id)

    current_app.logger.info(wording_sql)

    if search:
        wording_sql += ' AND (wording.whole_string like "%%{0}%%" or sub_w.translated_value like "%%{1}%%")'.format(
            search, search)

    wordings = db.engine.execute(wording_sql).fetchall()
    index = start + 1
    result = []
    for record in wordings[start:start+length]:
        result.append({
            'DT_RowId': 'row_{0}_{1}'.format(record[0], record[1]),
            'no': index,
            'module_key': '{0}@{1}'.format(os.path.basename(record[2].split('/res/')[0]), record[3]),
            'description': record[4],
            'whole_string': record[5],
            'translated_value': record[6]
        })
        index += 1

    return '{"recordsTotal": %s ,"recordsFiltered": %s,"data":%s}' % (len(wordings), len(wordings),
                                                                      json.dumps(result))


@local_manager.route('/send_back_translated_wording', methods=['POST'])
@login_required
def send_back_translated_wording():
    """翻译者的翻译结果验证不通过"""

    all_id = request.form.getlist('task_wording_id[]')
    sub_task = SubTask.query.filter_by(id=all_id[0].split('_')[1]).first()
    sub_task_wording_ids = []
    for sub_task_wording_id in all_id:
        sub_task_wording_ids.append(sub_task_wording_id.split('_')[2])

    for sub_task_wording in SubTaskCustomerWording.query.filter(
            db.and_(SubTaskCustomerWording.sub_task_id == sub_task.id,
                    SubTaskCustomerWording.customer_wording_id.in_(sub_task_wording_ids))).all():
        sub_task_wording.validate = -1
        db.session.add(sub_task_wording)

        # 判断是否有其他子任务中包含了此相同语言的相同字串，避免重复翻译
        other_task_wordings = SubTaskCustomerWording.query.join(SubTask).filter(
            db.and_(SubTaskCustomerWording.sub_task_id != sub_task.id,
                    SubTaskCustomerWording.customer_wording_id == sub_task_wording.customer_wording_id,
                    SubTaskCustomerWording.validate.in_([-1, 0, 1]),
                    SubTask.language_id == sub_task.language_id)).all()
        for other_task_wording in other_task_wordings:
            other_sub_task = SubTask.query.filter(SubTask.id == other_task_wording.sub_task_id).first()
            other_task_wording.validate = -1
            db.session.add(other_task_wording)
            other_sub_task.status = 2
            db.session.add(other_sub_task)

    sub_task.status = 2
    db.session.add(sub_task)
    db.session.commit()

    flash('Wording Send Back', 'info')
    return '{"result": true}'


@local_manager.route('/re_translation_wording', methods=['POST'])
@login_required
def re_translation_wording():
    """"已翻译的字串重新翻译"""

    all_id = request.form.getlist('task_wording_id[]')

    current_app.logger.info(all_id)

    sub_task = SubTask.query.filter_by(id=all_id[0].split('_')[1]).first()
    sub_task_wording_ids = []
    for sub_task_wording_id in all_id:
        sub_task_wording_ids.append(sub_task_wording_id.split('_')[2])

    for sub_task_wording in SubTaskCustomerWording.query.filter(
            db.and_(SubTaskCustomerWording.sub_task_id == sub_task.id,
                    SubTaskCustomerWording.customer_wording_id.in_(sub_task_wording_ids))).all():
        sub_task_wording.validate = 0
        sub_task_wording.has_translated = 0
        db.session.add(sub_task_wording)

    db.session.commit()

    flash('Wording Need Re-translation', 'info')
    return '{"result": true}'
