$("#current_task tr").live({
    mouseover:function(){
        $(this).css("cursor","pointer");
    }
});

//单击子任务行，显示子任务的字串
//单击操作行不显示
$('#current_task tbody').on( 'dblclick', 'td', function () {
    var tdSeq = $(this).parent().find("td").index($(this)[0]);
    if(tdSeq == 5){
        return;
    }
    window.location.href = $SCRIPT_ROOT + '/developer/sub_task_wording_page/'+$(this).parent().attr('data');
});


//取消子任务
function cancel_sub_task(sub_task_id){
    bootbox.confirm("Are you sure?", function(result) {
       if (result){
           $.getJSON(
                '/developer/cancel_sub_task',
                {
                    sub_task_id: sub_task_id,
                    sub_task_status: -1
                },
                function(data){
                    bootbox.alert("Success");
                    window.location.reload();
                }
           );
       }
    });
}

// 激活已取消的任务
function active_sub_task(sub_task_id){
    bootbox.confirm("Are you sure?", function(result) {
       if (result){
           $.getJSON(
                '/developer/cancel_sub_task',
                {
                    sub_task_id: sub_task_id,
                    sub_task_status: 0
                },
                function(data){
                    bootbox.alert("Success");
                    window.location.reload();
                }
           );
       }
    });
}