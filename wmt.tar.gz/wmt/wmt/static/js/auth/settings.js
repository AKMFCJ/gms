/**
 * Created by changjie.fan on 2015/11/10.
 */
$(function(){
    /*用户设置*/
    $('#email_submit').bind('click',function(){
        var data = {
            data: JSON.stringify({
                'email': $('#email').val()
            })
        };
        $.ajax({
            url: '/auth/change_email',
            type: 'POST',
            data: data,
            success: function(msg){
                alert(msg);
            }
        });
    });
});