# -*- coding:utf-8 -*-
__author__ = 'changjie.fan'

""""""

from datetime import datetime
import simplejson as json

from flask import render_template, redirect, url_for, request, flash, current_app, session
from flask.ext.login import login_required, current_user
from flask.ext.mail import Message

from wmt import db, mail
from . import translate_agency
from wmt.auth.models import User, Role
from wmt.customer.models import CustomerManager, Translator, TranslateAgency, Language
from wmt.task.models import Task, SubTask
from wmt.auth.util import new_account_email_notice


@translate_agency.route('/my_task')
@login_required
def my_task():
    """local manager的任务"""

    session['breadcrumbs'] = [session['breadcrumbs'][0]]
    session['breadcrumbs'].append({'text': 'MyTask', 'url': url_for('translate_agency.my_task')})
    session['menu_path'] = ['Task Manager', 'MyTask']

    agency = TranslateAgency.query.filter_by(user_id=current_user.id).first()

    # 正在翻译的、未分配的、翻译完成未确认的任务
    tasks = SubTask.query.join(Task.project).filter(
        db.and_(SubTask.translation_agency_id == agency.id,
                SubTask.status.in_([1, 2, 3]))).all()

    for task in tasks:
        if task.status == 0:
            task.status_name = 'need assign'
        elif task.status == 1:
            task.status_name = 'assign to local manager'
        elif task.status == 2:
            task.status_name = 'translating'
        elif task.status == 3:
            task.status_name = 'need validate'
        elif task.status == 4:
            task.status_name = 'need export'

    return render_template('/translate_agency/my_task_page.html', all_task=tasks)


@translate_agency.route('/sub_task_wording_page/<int:sub_task_id>', methods=['GET', 'POST'])
@login_required
def sub_task_wording_page(sub_task_id):
    """子任务翻译和为翻译的字串页面"""

    for breadcrumb in session['breadcrumbs']:
        if 'SubTask Info' == breadcrumb['text']:
            break
    else:
        session['breadcrumbs'].append({'text': 'SubTask Info',
                                       'url': url_for('translate_agency.sub_task_wording_page', sub_task_id=sub_task_id)})

    sub_task = SubTask.query.filter_by(id=sub_task_id).first()

    return render_template('translate_agency/sub_task_detail_info.html', sub_task=sub_task)


@translate_agency.route('/assign_task/<int:sub_task_id>', methods=['GET', 'POST'])
@login_required
def assign_task(sub_task_id):
    """任务分配给翻译者"""

    if request.method == 'POST':
        sub_task = SubTask.query.filter_by(id=sub_task_id).first()
        sub_task.translator_id = int(request.form.get('translator'))
        sub_task.status = 2
        db.session.add(sub_task)
        db.session.commit()
        return redirect(url_for('translate_agency.my_task'))
    else:
        for breadcrumb in session['breadcrumbs']:
            if 'SubTask Info' == breadcrumb['text']:
                break
        else:
            session['breadcrumbs'].append({'text': 'SubTask Info',
                                           'url': url_for('translate_agency.sub_task_wording_page', sub_task_id=sub_task_id)})

        sub_task = SubTask.query.filter_by(id=sub_task_id).first()

        agency_all_translator = Translator.query.join(TranslateAgency).filter(TranslateAgency.user_id == current_user.id).all()
        translators = []
        for translator in agency_all_translator:
            if sub_task.language in translator.language:
                translators.append(translator)

        if not translators:
            flash("You have not this {0} language's translator. "
                  "Please create a translator account for it".format(sub_task.language.name), 'info')

        return render_template('translate_agency/sub_task_detail_info.html',
                               sub_task=sub_task, translators=translators, is_assign_task=True)


@translate_agency.route('/translator_page')
@login_required
def translator_page():
    """翻译者账号管理"""

    session['breadcrumbs'] = [session['breadcrumbs'][0]]
    session['breadcrumbs'].append({'text': 'translator', 'url': url_for('customer_manager.translator_page')})
    session['menu_path'] = ['Translator Manager', 'Translator']

    translators = Translator.query.join(TranslateAgency).filter(TranslateAgency.user_id == current_user.id).all()

    return render_template('/translate_agency/translator_page.html', translators=translators)


@translate_agency.route('/add_translator', methods=['GET', 'POST'])
@login_required
def add_translator():
    """新增翻译账号"""

    for breadcrumb in session['breadcrumbs']:
        if 'New Translator' == breadcrumb['text']:
            break
    else:
        session['breadcrumbs'].append({'text': 'New Translator', 'url': url_for('customer_manager.add_translator')})

    if request.method == 'POST':
        username = request.form['username']
        email = request.form['email']
        password = request.form['password']
        password2 = request.form['password2']

        language_ids = request.form.getlist('language')

        other_translator = User.query.filter_by(email=email).first()
        if other_translator is not None:
            flash(u'This Email has registered', 'danger')
        else:
            if password != password2:
                flash(u'The two passwords do not match', 'danger')
            else:
                translator = Translator()
                translator.username = username
                translator.password = password
                translator.email = email
                translator.translate_agency = TranslateAgency.query.filter_by(user_id=current_user.id).first()

                for language in Language.query.filter(Language.id.in_(language_ids)):
                    translator.language.append(language)

                db.session.add(translator)
                db.session.commit()

                user = User.query.filter_by(id=translator.id).first()
                user.role = Role.query.filter_by(name='translator').first()

                db.session.add(user)
                db.session.commit()
                new_account_email_notice(request.url_root, translator.email, request.form['password'])
                flash(u'Success!', 'info')

    return render_template('/translate_agency/translator_edit.html',
                           translator=None, languages=Language.query.all())


@translate_agency.route('/edit_translator/<int:translator_id>', methods=['GET', 'POST'])
@login_required
def edit_translator(translator_id):
    """编辑翻译账号"""

    for breadcrumb in session['breadcrumbs']:
        if 'Edit Translator' == breadcrumb['text']:
            break
    else:
        session['breadcrumbs'].append({'text': 'Edit Translator',
                                       'url': url_for('customer_manager.edit_translator', translator_id=translator_id)})

    translator = Translator.query.filter_by(id=translator_id).first()

    if request.method == 'POST':
        username = request.form['username']
        email = request.form['email']
        password = request.form['password']
        password2 = request.form['password2']
        language_ids = request.form.getlist('language')

        other_translator = User.query.filter_by(email=email).first()
        if other_translator is not None and other_translator.id != translator.id:
            flash(u'This Email has registered', 'danger')
        else:
            if password != translator.password_hash and password != password2:
                flash(u'The two passwords do not match', 'danger')
            else:
                translator.username = username
                if translator.password_hash != password:
                    translator.password = password
                translator.email = email
                translator.language = []
                for language in Language.query.filter(Language.id.in_(language_ids)):
                    translator.language.append(language)

                db.session.add(translator)
                db.session.commit()

                flash(u'Success!', 'info')

    current_app.logger.info(translator.language)
    return render_template('/translate_agency/translator_edit.html',
                           translator=translator, languages=Language.query.all())
