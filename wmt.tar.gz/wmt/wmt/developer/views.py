# -*- coding:utf-8 -*-
__author__ = 'changjie.fan'

"""开发工程师管理界面"""
import os
from datetime import datetime
import time

import simplejson as json
from flask import request, current_app, render_template, url_for, session, redirect, send_file, flash
from flask.ext.login import login_required, current_user
from flask.ext.mail import Mail, Message
from werkzeug import secure_filename

from . import developer
from wmt import db, mail
from wmt.auth.models import Role
from wmt.task.models import Task, SubTask, SubTaskCustomerWording
from wmt.project.models import Project
from wmt.customer.models import Customer, CustomerManager, Translator
from wmt.utils.excelOption import ExcelOptions, WordingValueObject
from wmt.wording.models import Wording, CustomerWording, Language


@developer.route('/my_task')
@login_required
def my_task():
    """工程师首页"""

    session['breadcrumbs'] = [session['breadcrumbs'][0]]
    session['breadcrumbs'].append({'text': 'Task Manager', 'url': url_for('developer.my_task')})
    session['menu_path'] = ['Task Manager', 'MyTask']

    all_task = Task.query.filter(
        db.and_(Task.creator_id == current_user.id,
                Task.status.in_([0, 1, 2, 3, 4]))).order_by('id').all()
    for task in all_task:
        if task.status == 0:
            task.status_name = 'need assign'
        elif task.status == 1:
            task.status_name = 'has assign'
        elif task.status == 2:
            task.status_name = 'translating'
        elif task.status == 3:
            task.status_name = 'need validate'
        elif task.status == 4:
            task.status_name = 'need export'

    return render_template('developer/my_task.html', all_task=all_task)


@developer.route('/create_task',  methods=['GET', 'POST'])
@login_required
def create_task():
    """工程师创建"""

    for breadcrumb in session['breadcrumbs']:
        if 'New Task' == breadcrumb['text']:
            break
    else:
        session['breadcrumbs'].append({'text': 'New Task', 'url': url_for('developer.create_task')})

    # 只有项目的负责人可以创建任务
    my_project = Project.query.filter_by(develop_lead_id=current_user.id)

    if request.method == 'POST':
        # 主任务名称
        project = Project.query.filter_by(id=request.form['project']).first()
        task_obj_name = "%s_%04d" % (project.name, project.task_count)
        # 保存上传文件
        excel_file = request.files['excel_file_name']
        local_dir = current_app.config['WMT_TEMP_DIR']
        if not os.path.exists(local_dir):
            os.makedirs(local_dir)
        local_path = os.path.join(local_dir, '{0}.xlsx'.format(task_obj_name))
        excel_file.save(local_path)

        # 解析Excel文件中的字串
        start_time = time.time()

        excel_option = ExcelOptions(local_path)
        wordings = excel_option.read_records(project.name, project.platform_vendor)
        if not wordings:
            flash("Can't parse the Excel file.Please check your project name and String path", 'warning')
            return render_template('developer/create_task.html', task=None, my_project=my_project)

        current_app.logger.info('read Excel:%s' % str(time.time()-start_time))

        current_app.logger.info('wordings_count:%s' % str(len(wordings)))
        start_time = time.time()
        # 数据库已存在的字串
        exists_wordings = Wording.query.filter(
            db.and_(Wording.abs_path.in_([tmp.abs_path for tmp in wordings]),
                    Wording.whole_string.in_([tmp.whole_string for tmp in wordings]))).all()

        current_app.logger.info('exists_wordings:%s' % str(len(exists_wordings)))
        # 新增和已存在的字串
        task_wordings = []
        exists_wordings_dict = {}
        for exists_wording in exists_wordings:
            exists_wordings_dict.update({exists_wording.abs_path: exists_wording})
            task_wordings.append(exists_wording)
        exists_wordings_path = exists_wordings_dict.keys()
        current_app.logger.info(str(len(exists_wordings)))
        # 向数据添加新增的字串
        for wording in wordings:
            # whole String有参数的, 还需要判断whole String和数据库中已存在的whole string是否一致，不一致的就作为新增字串
            if wording.abs_path not in exists_wordings_path:
                db.session.add(wording)
                task_wordings.append(wording)
        db.session.commit()
        current_app.logger.info(str(len(exists_wordings)))

        current_app.logger.info('task_wording_count:%s' % str(len(task_wordings)))
        current_app.logger.info('Add new wording:%s' % str(time.time()-start_time))

        start_time = time.time()
        customer = project.customer

        # 数据库客户已有的字串
        customer_exists_wording_ids = []
        all_customer_wording = []
        for customer_wording in CustomerWording.query.filter(
                db.and_(CustomerWording.wording_id.in_([tmp.id for tmp in exists_wordings]),
                        CustomerWording.customer_id == customer.id)).all():

                customer_exists_wording_ids.append(customer_wording.wording_id)
                all_customer_wording.append(customer_wording)

        current_app.logger.info(str(len(customer_exists_wording_ids)))
        # 新增客户字串
        has_new = False
        for wording in task_wordings:
            if wording.id not in customer_exists_wording_ids:
                has_new = True
                customer_wording_obj = CustomerWording()
                customer_wording_obj.wording = wording
                customer_wording_obj.customer = customer
                db.session.add(customer_wording_obj)
                all_customer_wording.append(customer_wording_obj)

        if has_new:
            db.session.commit()

        all_customer_wording_ids = [str(tmp.id) for tmp in all_customer_wording]
        current_app.logger.info('all_customer_wording_count:%s' % str(len(all_customer_wording)))
        current_app.logger.info('Add Customer Wording:%s' % str(time.time()-start_time))

        start_time = time.time()
        # 指定此任务的语言
        task_languages = Language.query.filter(Language.id.in_(request.form.getlist('language'))).all()

        # 新增客户翻译主任务
        task_obj = Task()
        task_obj.creator = current_user
        task_obj.create_time = datetime.now()
        task_obj.project = project
        project.task_count += 1
        task_obj.name = task_obj_name
        task_obj.customer_wording = all_customer_wording
        for language in task_languages:
            task_obj.language.append(language)

        task_obj.status = 0

        db.session.add(task_obj)
        db.session.add(project)
        db.session.commit()

        current_app.logger.info('Add master task:%s' % str(time.time()-start_time))

        start_time = time.time()
        # 从数据库中查询出每种语言已翻译过的字串
        value_sql = "SELECT c_w.id, c_v.language_id, c_v.translated_value FROM " \
                    "customer_wording_language_value AS c_v JOIN customer_wording AS c_w ON " \
                    "c_v.customer_wording_id=c_w.id WHERE c_w.customer_id={0} AND c_w.id " \
                    "IN({1})".format(customer.id, ','.join(all_customer_wording_ids))

        # 每种语言下翻译过的字串
        all_language_translated = {}
        for tmp in db.session.execute(value_sql).fetchall():
            if tmp[1] in all_language_translated.keys():
                all_language_translated[tmp[1]].update({tmp[0]: tmp[2]})
            else:
                all_language_translated.update({tmp[1]: {tmp[0]: tmp[2]}})

        task_language_count = len(task_languages)
        has_translated_language = 0
        # 待分配的任务
        need_assign_task = []
        # 为每个翻译者的每种语言创建一个子任务
        all_customer_wording_count = len(all_customer_wording)
        current_app.logger.info('count_wording:%s' % str(all_customer_wording_count))
        for language in task_languages:
                sub_task_obj = SubTask()
                sub_task_obj.name = '_'.join([task_obj.name, language.abbreviation])
                sub_task_obj.task = task_obj
                sub_task_obj.language = language
                sub_task_obj.create_time = datetime.now()
                sub_task_obj.status = 0

                history_translated_count = 0
                # 此语言有已经翻译过的字串
                if language.id in all_language_translated.keys() and all_language_translated[language.id]:
                    all_translated_wording = all_language_translated[language.id]

                    for customer_wording in all_customer_wording:
                        sub_task_customer_wording = SubTaskCustomerWording(translated_value='')
                        sub_task_customer_wording.customer_wording = customer_wording
                        if customer_wording.id in all_translated_wording.keys():
                            sub_task_customer_wording.has_translated = True
                            sub_task_customer_wording.validate = 2
                            sub_task_customer_wording.translated_value = all_translated_wording[customer_wording.id]
                            history_translated_count += 1
                        sub_task_obj.customer_wording.append(sub_task_customer_wording)
                else:
                    for customer_wording in all_customer_wording:
                        sub_task_customer_wording = SubTaskCustomerWording(translated_value='')
                        sub_task_customer_wording.customer_wording = customer_wording
                        sub_task_obj.customer_wording.append(sub_task_customer_wording)

                sub_task_obj.history_translated_count = history_translated_count
                # 如果所有字串都已经翻译过，那么子任务就完成了

                if history_translated_count == all_customer_wording_count:
                    sub_task_obj.status = 4
                    sub_task_obj.progress = 100
                    has_translated_language += 1

                db.session.add(sub_task_obj)
                need_assign_task.append((language, sub_task_obj))

        db.session.commit()

        current_app.logger.info('Create Sub task:%s' % str(time.time()-start_time))
        # 所有语言都已翻译完成时，主任务状态为已完成未导出
        if task_language_count == has_translated_language:
            task_obj.progress = 100
            task_obj.status = 4
            db.session.add(task_obj)
        db.session.commit()

        # 走完整的check流程
        if customer.work_flow:
            # 已经测试过，邮件可以正常发出
            # 发邮件通知global manager有新的翻译任务需求其分配
            if customer.work_flow and task_obj.status == 0:
                customer_global_manager = CustomerManager.query.join(CustomerManager.customer).join(Role).filter(
                    db.and_(customer == customer, Role.name == 'global_manager',)).all()
                msg = Message(
                    '[WMT]New Translate Task',
                    sender='Tinno@tinno.com',
                    recipients=[global_manager.email for global_manager in customer_global_manager]
                )
                msg.body = "You has new Translate task"
                mail.send(msg)
        else:
            translators = Translator.query.filter(Translator.customer_id == customer.id).all()

            for sub_task_language, sub_task_obj in need_assign_task:
                for translator in translators:
                    current_app.logger.info(translator)
                    if sub_task_language in translator.language:
                        sub_task_obj.translator_id = translator.id
                        db.session.add(sub_task_obj)
                        msg = Message(
                            '[WMT]New Translate Task',
                            sender='Tinno@tinno.com',
                            recipients=[translator.email]
                        )
                        msg.body = "You has new Translate task"
                        mail.send(msg)
            db.session.commit()

        return redirect(url_for('developer.my_task'))

    return render_template('developer/create_task.html', task=None, my_project=my_project)


@developer.route('/sub_task_page/<int:task_id>')
@login_required
def sub_task_page(task_id):
    """主任务的所有子任务"""

    for breadcrumb in session['breadcrumbs']:
        if 'SubTask' == breadcrumb['text']:
            break
    else:
        session['breadcrumbs'].append({'text': 'SubTask', 'url': url_for('developer.sub_task_page', task_id=task_id)})

    sub_tasks = SubTask.query.filter_by(task_id=task_id).all()
    task_obj = Task.query.filter_by(id=task_id).first()
    for sub_task in sub_tasks:
        if sub_task.status == 0:
            sub_task.status_name = 'need assign'
        elif sub_task.status == 1:
            sub_task.status_name = 'has assign'
        elif sub_task.status == 2:
            sub_task.status_name = 'translating'
        elif sub_task.status == 3:
            sub_task.status_name = 'need validate'
        elif sub_task.status == 4:
            sub_task.status_name = 'need export'
        elif sub_task.status == -1:
            sub_task.status_name = 'cancel'

    return render_template('developer/sub_task_page.html', task=task_obj, sub_tasks=sub_tasks)


@developer.route('/sub_task_all_wording_data')
@login_required
def sub_task_all_wording_data():
    """子任务的所有的字串(已翻译的、未翻译的)分页数据"""

    start = int(request.args.get('start', 0))
    length = int(request.args.get('length', 10))
    sub_task_id = request.args.get('sub_task_id')
    search = request.args.get('search[value]')

    wording_sql = "SELECT wording.path, wording.name, wording.description, wording.whole_string, " \
                  "sub_w.translated_value FROM sub_task JOIN sub_task_customer_wording as " \
                  "sub_w ON sub_task.id=sub_w.sub_task_id JOIN customer_wording as c_w ON " \
                  "sub_w.customer_wording_id=c_w.id JOIN wording ON c_w.wording_id=wording.id WHERE " \
                  "sub_task.id={0}".format(sub_task_id)
    if search:
        wording_sql += ' AND (wording.whole_string like "%%{0}%%" or sub_w.translated_value like "%%{1}%%")'.format(search, search)

    wordings = db.engine.execute(wording_sql).fetchall()
    index = start + 1
    result = []
    for record in wordings[start:start+length]:
        module_key = '{0}@{1}'.format(os.path.basename(record[0].split('/res/')[0]), record[1])
        result.append([index, module_key, record[2], record[3], record[4]])
        index += 1

    return '{"recordsTotal": %s ,"recordsFiltered": %s,"data":%s}' % (len(wordings), len(wordings),
                                                                      json.dumps(result))


@developer.route('/sub_task_need_translate_wording_data')
@login_required
def sub_task_need_translate_wording_data():
    """
    子任务中需要翻译的字串
    """

    start = int(request.args.get('start', 0))
    length = int(request.args.get('length', 10))
    sub_task_id = request.args.get('sub_task_id')
    search = request.args.get('search[value]')

    wording_sql = "SELECT wording.path, wording.name, wording.description, wording.whole_string, " \
                  "sub_w.translated_value FROM sub_task JOIN sub_task_customer_wording as " \
                  "sub_w ON sub_task.id=sub_w.sub_task_id JOIN customer_wording as c_w ON " \
                  "sub_w.customer_wording_id=c_w.id JOIN wording ON c_w.wording_id=wording.id WHERE " \
                  "sub_w.has_translated=0 AND sub_task.id={0}".format(sub_task_id)

    if search:
        wording_sql += ' AND (wording.whole_string like "%%{0}%%" or sub_w.translated_value like "%%{1}%%")'.format(search, search)

    wordings = db.engine.execute(wording_sql).fetchall()
    index = start + 1
    result = []
    for record in wordings[start:start+length]:
        module_key = '{0}@{1}'.format(os.path.basename(record[0].split('/res/')[0]), record[1])
        result.append([index, module_key, record[2], record[3], record[4]])
        index += 1

    return '{"recordsTotal": %s ,"recordsFiltered": %s,"data":%s}' % (len(wordings), len(wordings),
                                                                      json.dumps(result))


@developer.route('/sub_task_has_translated_wording_data')
@login_required
def sub_task_has_translated_wording_data():
    """
    子任务中已经翻译过的字串
    """

    start = int(request.args.get('start', 0))
    length = int(request.args.get('length', 10))
    sub_task_id = request.args.get('sub_task_id')
    search = request.args.get('search[value]')

    wording_sql = "SELECT wording.path, wording.name, wording.description, wording.whole_string, " \
                  "sub_w.translated_value FROM sub_task JOIN sub_task_customer_wording as " \
                  "sub_w ON sub_task.id=sub_w.sub_task_id JOIN customer_wording as c_w ON " \
                  "sub_w.customer_wording_id=c_w.id JOIN wording ON c_w.wording_id=wording.id WHERE " \
                  "sub_w.has_translated=1 AND sub_w.validate=2 AND sub_task.id={0}".format(sub_task_id)

    if search:
        wording_sql += ' AND (wording.whole_string like "%%{0}%%" or sub_w.translated_value like "%%{1}%%")'.format(search, search)

    current_app.logger.info(wording_sql)
    wordings = db.engine.execute(wording_sql).fetchall()
    index = start + 1
    result = []
    for record in wordings[start:start+length]:
        module_key = '{0}@{1}'.format(os.path.basename(record[0].split('/res/')[0]), record[1])
        result.append([index, module_key, record[2], record[3], record[4]])
        index += 1

    return '{"recordsTotal": %s ,"recordsFiltered": %s,"data":%s}' % (len(wordings), len(wordings),
                                                                      json.dumps(result))


@developer.route('/cancel_sub_task', methods=['GET'])
@login_required
def cancel_sub_task():
    """取消sub_task"""

    sub_task_id = request.args.get('sub_task_id', '')
    sub_task_status = request.args.get('sub_task_status', '')
    sub_task = SubTask.query.filter_by(id=sub_task_id).first()
    sub_task.status = int(sub_task_status)
    db.session.add(sub_task)
    db.session.commit()

    # 检查是否所有子任务都取消了, 如果是则主任务的状态也为取消
    other_sub_task = SubTask.query.filter(db.and_(SubTask.task_id == sub_task.task_id, SubTask.status != -1)).all()
    if not other_sub_task:
        task = sub_task.task
        task.status = -1
        db.session.add(task)
        db.session.commit()
        # 已经测试过，邮件可以正常发出
        msg = Message(
            '[WMT]This %s task has cancel' % task.name,
            sender='Tinno@tinn.com',
            recipients=[task.creator.email]
        )
        msg.body = "Task has cancel. %s" % task.name
        mail.send(msg)

    return '{"result": true}'


@developer.route('/cancel_task', methods=['GET'])
@login_required
def cancel_task():
    """取消主task"""

    task_id = request.args.get('task_id', '')
    task = Task.query.filter_by(id=task_id).first()
    task.status = -1
    for sub_task in SubTask.query.filter_by(task_id=task_id).all():
        sub_task.status = -1
        db.session.add(sub_task)
    db.session.add(task)

    db.session.commit()

    return '{"result": true}'


@developer.route('/export_task/')
@login_required
def export_task():
    """导出已经翻译完成的任务"""

    task_id = request.args.get('task_id')
    task_obj = Task.query.filter_by(id=task_id).first()
    # 读取任务的原始Excel文件

    read_excel_option = ExcelOptions(os.path.join(current_app.config['WMT_TEMP_DIR'],
                                                  '{0}.xlsx'.format(task_obj.name)))
    abs_path = read_excel_option.read_abs_path()

    wording_value_sql = "SELECT abs_path, wording.name, wording.description, wording.sub_description, " \
                        "wording.whole_string, w_l.abbreviation, c_w_l_v.translated_value, w_l.name FROM task " \
                        "JOIN sub_task ON task.id=sub_task.task_id JOIN sub_task_customer_wording AS s_t_c_w ON " \
                        "sub_task.id=s_t_c_w.sub_task_id JOIN wmt_language AS w_l ON w_l.id=sub_task.language_id " \
                        "JOIN customer_wording AS c_w ON c_w.id=s_t_c_w.customer_wording_id JOIN wording ON " \
                        "wording.id=c_w.wording_id JOIN customer_wording_language_value AS c_w_l_v ON " \
                        "c_w_l_v.customer_wording_id=c_w.id AND c_w_l_v.language_id=sub_task.language_id  " \
                        "WHERE task.id={0} AND s_t_c_w.translated_value != ''".format(task_id)

    current_app.logger.info(wording_value_sql)
    wording_records = db.session.execute(wording_value_sql).fetchall()
    # 字符路径为key
    languages = {}
    wording_value = {}
    work_language = []
    for wording in wording_records:
        work_language.append(wording[5])
        # 存储语言缩写和全称
        languages.update({wording[5]: wording[7]})
        if wording[0] in wording_value.keys():
            wording_value[wording[0]].language_value.update({wording[5]: wording[6]})
        else:
            wording_value_object = WordingValueObject(
                abs_path[wording[0]].replace('/', '\\'), wording[1], wording[2], wording[3], wording[4])
            wording_value_object.language_value = {wording[5]: wording[6]}
            wording_value.update({wording[0]: wording_value_object})

    result_excel_name = "{0}_result.xlsx".format(task_obj.name)
    file_path = os.path.join(current_app.config['WMT_TEMP_DIR'], result_excel_name)
    excel_option = ExcelOptions(file_path)

    excel_option.export_xls(wording_value, list(set(work_language)), languages, current_app)
    task_obj.status = 5
    task_obj.export_time = datetime.now()
    for sub_task in SubTask.query.filter(db.and_(SubTask.task_id == task_obj.id, SubTask.status == 4)).all():
        sub_task.status = 5
        db.session.add(sub_task)
    db.session.add(task_obj)
    db.session.commit()

    return send_file(
        open(file_path, 'rb'),
        as_attachment=True, attachment_filename=result_excel_name)


@developer.route('/history_task_page')
@login_required
def history_task_page():
    """显示历史任务"""

    for breadcrumb in session['breadcrumbs']:
        if 'History' == breadcrumb['text']:
            break
    else:
        session['breadcrumbs'].append({'text': 'History', 'url': url_for('developer.history_task_page')})

    project_sql = "SELECT id, name FROM project JOIN project_member AS pro_m ON pro_m.project_id=project.id WHERE " \
                  "pro_m.user_id={0} OR project.develop_lead_id={1} GROUP BY project.id".format(current_user.id,
                                                                                                current_user.id)
    customers = Customer.query.all()
    projects = db.engine.execute(project_sql).fetchall()

    return render_template('developer/history_task_page.html', customers=customers, projects=projects)


@developer.route('/history_task_data')
@login_required
def history_task_data():
    """历史任务显示所有任务"""

    start = int(request.args.get('start', 0))
    length = int(request.args.get('length', 10))

    customer_id = request.args.get('customer_id')
    project_id = request.args.get('project_id')
    option_date = request.args.get('option_date')
    from_date = request.args.get('from_date')
    to_date = request.args.get('to_date')

    task_sql = "SELECT task.id, task.name, customer.name, task.status, task.create_time, task.submit_time, " \
               "task.export_time, wmt_user.username FROM task JOIN project ON task.project_id=project.id JOIN " \
               "customer ON project.customer_id=customer.id JOIN wmt_user ON task.creator_id=wmt_user.id " \
               "WHERE task.status=2"

    if customer_id and customer_id != 'undefined':
        task_sql += ' AND customer.id={0}'.format(customer_id)

    if project_id and project_id != 'undefined':
        task_sql += ' AND project.id={0}'.format(project_id)

    if from_date and from_date != 'undefined':
        task_sql += ' AND task.{0} >= "{1}"'.format(option_date, from_date)

    if to_date and to_date != 'undefined':
        task_sql += ' AND task.{0} <= "{1}"'.format(option_date, to_date)

    tasks = db.engine.execute(task_sql).fetchall()
    result = []
    index = start + 1
    for task in tasks[start*length: (start+1)*length]:
        record = {
            'index': index,
            'task_id': task[0],
            'task_name': task[1],
            'customer_name': task[2],
            'status': 'export',
            'create_time': str(task[4]),
            'submit_time': str(task[5]),
            'export_time': str(task[6]),
            'creator': task[7]
        }
        result.append(record)
        index += 1

    return '{"recordsTotal":%s,"recordsFiltered":%s,"data":%s}' % (len(tasks), len(tasks), json.dumps(result))


@developer.route('/wording_search')
@login_required
def wording_search():
    """字符串检索"""

    session['breadcrumbs'] = [session['breadcrumbs'][0]]
    session['breadcrumbs'].append({'text': 'Task Manager', 'url': url_for('developer.wording_search')})
    session['menu_path'] = ['Wording', 'Search']

    search_type = request.args.get('search_type', '').strip()
    search = request.args.get('search', '').strip()
    result = []

    if search_type and search:
        wording_sql = "SELECT wording.path, wording.name AS wording_name, wording.whole_string, " \
                      "c_w_v.translated_value, w_l.name AS language_name, customer.name AS customer_name, " \
                      "sub_task.name AS sub_task_name, sub_task.submit_time, wmt_user.username FROM wording JOIN customer_wording " \
                      "AS c_w ON wording.id=c_w.wording_id JOIN customer ON customer.id=c_w.customer_id JOIN " \
                      "customer_wording_language_value AS c_w_v ON c_w.id=c_w_v.customer_wording_id JOIN " \
                      "wmt_language AS w_l ON c_w_v.language_id=w_l.id JOIN sub_task ON " \
                      "c_w_v.sub_task_id=sub_task.id JOIN translator on sub_task.translator_id=translator.id JOIN " \
                      "wmt_user ON wmt_user.id=translator.id WHERE {0} like '%%{1}%%'".format(search_type, search)

        current_app.logger.info(wording_sql)
        wordings = db.session.execute(wording_sql).fetchall()

        index = 1
        for wording in wordings:
            result.append({
                'index': index,
                'path': wording[0],
                'name': wording[1],
                'whole_string': wording[2],
                'translated_value': wording[3],
                'language': wording[4],
                'customer_name': wording[5],
                'sub_task_name': wording[6],
                'submit_time': wording[7],
                'translator': wording[8],
            })
            index += 1

    return render_template('developer/wording_search_page.html',search_type=search_type, search=search, wordings=result)


@developer.route('/sub_task_wording_page/<int:sub_task_id>', methods=['GET', 'POST'])
@login_required
def sub_task_wording_page(sub_task_id):
    """子任务翻译和为翻译的字串页面"""

    sub_task = SubTask.query.filter_by(id=sub_task_id).first()

    return render_template('developer/sub_task_wording.html', sub_task=sub_task)


@developer.route('/download_string_tool')
@login_required
def download_string_tool():
    """字符串工具下载"""

    return send_file(open(current_app.config['WMT_STRING_TOOL'], 'rb'),
                     as_attachment=True, attachment_filename=os.path.basename(current_app.config['WMT_STRING_TOOL']))