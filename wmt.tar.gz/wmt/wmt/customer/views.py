# -*- coding:utf-8 -*-

__author__ = 'roy'
__created__ = '11/18/15'

""""""

from flask import render_template, redirect, url_for, request, flash, current_app, session
from flask.ext.login import login_required

import simplejson as json

from . import customer
from models import Customer, Language
from wmt import db
from wmt.project.models import Project


@customer.route('/customer_page')
@login_required
def customer_page():
    session['breadcrumbs'] = [session['breadcrumbs'][0]]
    session['breadcrumbs'].append({'text': 'Customer Manager', 'url': url_for('customer.customer_page')})
    session['menu_path'] = ['系统管理', '客户管理']

    return render_template('admin/customer/customer_page.html',
                           customers=Customer.query.all())


@customer.route('/add_customer', methods=['GET', 'POST'])
@login_required
def add_customer():
    """添加客户"""

    for breadcrumb in session['breadcrumbs']:
        if 'New Customer' == breadcrumb['text']:
            break
    else:
        session['breadcrumbs'].append({'text': 'New Customer', 'url': url_for('customer.add_customer')})

    if request.method == 'POST':
        new_customer = Customer()
        new_customer.name = request.form['name']
        if request.form.get('work_flow', 'off') == 'on':
            new_customer.work_flow = True
        else:
            new_customer.work_flow = False

        if Customer.query.filter_by(name=new_customer.name).first() is not None:
            flash(u'相同名称的客户已存在', 'danger')
        else:
            for language in Language.query.filter(Language.id.in_(request.form.getlist('language'))):
                new_customer.language.append(language)

            db.session.add(new_customer)
            db.session.commit()
            flash(u'新增成功', 'info')

    languages = Language.query.all()

    return render_template('admin/customer/customer_edit.html', customer=None, languages=languages)


@customer.route('/edit_customer/<int:customer_id>', methods=['GET', 'POST'])
@login_required
def edit_customer(customer_id):
    """添加客户"""

    for breadcrumb in session['breadcrumbs']:
        if 'Edit Customer' == breadcrumb['text']:
            break
    else:
        session['breadcrumbs'].append({'text': 'Edit Customer',
                                       'url': url_for('customer.edit_customer', customer_id=customer_id)})

    if request.method == 'POST':
        customer_obj = Customer.query.filter_by(id=customer_id).first()
        name = request.form['name']
        other_customer = Customer.query.filter_by(name=name).first()

        if other_customer is not None and other_customer.id != customer_id:
            flash(u'相同名称的客户已存在', 'danger')
        else:
            customer_obj.name = name
            if request.form.get('work_flow') == 'on':
                customer_obj.work_flow = True
            else:
                customer_obj.work_flow = False
            customer_obj.language = []
            for language in Language.query.filter(Language.id.in_(request.form.getlist('language'))):
                customer_obj.language.append(language)

            db.session.add(customer_obj)
            db.session.commit()
            flash(u'修改成功', 'info')
    else:
        customer_obj = Customer.query.filter_by(id=customer_id).first()

    languages = Language.query.all()

    return render_template('admin/customer/customer_edit.html', customer=customer_obj, languages=languages)


@customer.route('/language_page')
@login_required
def language_page():
    """语言"""

    session['breadcrumbs'] = [session['breadcrumbs'][0]]
    session['breadcrumbs'].append({'text': 'Language Manager', 'url': url_for('customer.language_page')})
    session['menu_path'] = ['系统管理', '语言管理']

    return render_template('admin/language/language_page.html', languages=Language.query.all())


@customer.route('/add_language', methods=['POST'])
@login_required
def add_language():
    """新增语言"""

    language_id = request.form['language_id']
    name = request.form['name'].strip()
    abbreviation = request.form['abbreviation'].strip()

    other_language = Language.query.filter_by(name=name).first()

    # 编辑
    if language_id:
        language = Language.query.filter_by(id=int(language_id)).first()
        if other_language is not None and other_language.id != language.id:
            flash(u'相同名称的语言已存在', 'danger')
        else:
            language.name = name
            language.abbreviation = abbreviation

            db.session.add(language)
            db.session.commit()

            flash(u'更新成功!', 'info')
    # 新增
    else:
        if other_language is not None:
            flash(u'相同名称的语言已存在', 'danger')
        else:
            language = Language()
            language.name = name
            language.abbreviation = abbreviation

            db.session.add(language)
            db.session.commit()

            flash(u'新增成功!', 'info')

    return redirect(url_for('customer.language_page'))


@customer.route('/get_customer_language')
@login_required
def get_customer_language():
    """获取指定客户的语言集合"""

    customer_id = request.args.get('customer_id')
    project_id = request.args.get('project_id')
    project_languages = None
    all_language = []

    if project_id != '0':
        project_languages = [language.id for language in Project.query.filter_by(id=project_id).first().languages]
    if project_languages:
        for language in Customer.query.filter_by(id=customer_id).first().language:
            if language.id in project_languages:
                all_language.append({'id': language.id, 'name': language.name, 'selected': 'selected'})
            else:
                all_language.append({'id': language.id, 'name': language.name, 'selected': ''})
    else:
        for language in Customer.query.filter_by(id=customer_id).first().language:
            all_language.append({'id': language.id, 'name': language.name, 'selected': ''})

    return json.dumps(all_language)
