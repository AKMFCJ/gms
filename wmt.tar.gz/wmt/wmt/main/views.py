# -*- coding:utf-8 -*-
__author__ = 'changjie.fan'

""""""
from flask import render_template, redirect, url_for, request, current_app
from flask.ext.login import login_required, current_user

from . import main


@main.route('/', methods=['GET', 'POST'])
@login_required
def index():
    """按不同的角色定位到不同的"""

    return redirect(url_for(current_user.role.index_page))
