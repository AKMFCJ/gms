# -*- coding:utf-8 -*-
__author__ = 'changjie.fan'

"""翻译任务"""
from datetime import datetime

from wmt import db
from wmt.customer.models import Language

task_customer_wording = db.Table('task_customer_wording', db.metadata,
                                 db.Column('task_id', db.Integer, db.ForeignKey('task.id')),
                                 db.Column('wording_id', db.Integer, db.ForeignKey('customer_wording.id')))

task_language = db.Table('task_language', db.metadata,
                         db.Column('task_id', db.Integer, db.ForeignKey('task.id')),
                         db.Column('language_id', db.Integer, db.ForeignKey('wmt_language.id')))


class Task(db.Model):
    """翻译主任务"""

    __tablename__ = 'task'

    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(200), unique=True)
    # 任务生成时间
    create_time = db.Column(db.DateTime)
    # 任务完成时间
    submit_time = db.Column(db.DateTime)
    # 任务状态-1 取消 0 待分配 1 已分配给local_manager或translate_agency 2 已分配给translator 3 待验证 4 待导出 5 已导出
    # 流程任务有才有 待分配和待确认这个两个状态
    status = db.Column(db.Integer, default=0)
    # 任务翻译进度
    progress = db.Column(db.Integer)
    # 备注信息
    note = db.Column(db.String(200), nullable=True)

    # 导出时间
    export_time = db.Column(db.DateTime)

    # 任务创建人
    creator_id = db.Column(db.Integer, db.ForeignKey('wmt_user.id'))
    creator = db.relationship('User', backref=db.backref('task', order_by=id))
    # 任务所属项目
    project_id = db.Column(db.Integer, db.ForeignKey('project.id'))
    project = db.relationship('Project', backref=db.backref('task', order_by=id))

    # 需要翻译的语言
    language = db.relationship('Language', secondary='task_language', backref='task')

    # 翻译字串
    customer_wording = db.relationship('CustomerWording', secondary='task_customer_wording', backref='task')

    def __repr__(self):
        return "<Task %r>" % self.name


class ExcelFile(db.Model):
    """翻译任务的原Excel文件"""

    __tablename__ = 'task_excel_file'

    id = db.Column(db.Integer, primary_key=True)
    task_id = db.Column(db.Integer, db.ForeignKey('task.id'))
    task = db.relationship('Task', backref=db.backref('task_excel_file', order_by=id))
    content = db.Column(db.Text)
    upload_time = db.Column(db.DateTime, default=datetime.now())

    def __init__(self, task, content, upload_time):
        self.task = task
        self.content = content
        self.upload_time = upload_time

    def __repr__(self):
        return "<ExcelFile %r>" % self.task.name


# 一个任务多个字串
class SubTaskCustomerWording(db.Model):
    """子任务和客户字串一对多的中间关联表"""

    __tablename__ = 'sub_task_customer_wording'

    sub_task_id = db.Column(db.Integer, db.ForeignKey('sub_task.id'), primary_key=True)
    customer_wording_id = db.Column(db.Integer, db.ForeignKey('customer_wording.id'), primary_key=True)
    customer_wording = db.relationship('CustomerWording')
    translated_value = db.Column('translated_value', db.String(500), default='')
    has_translated = db.Column(db.Boolean, default=False)
    # 字串状态-2 已取消 -1 验证不通过 0未翻译 1 待验证 2 已验证通过
    validate = db.Column(db.Integer, default=0)
    # 确认过不的原因
    validate_msg = db.Column(db.String(200), nullable=True)
    # 确认时间
    validate_time = db.Column(db.DateTime)
    # submitted时间
    submitted_time = db.Column(db.DateTime)
    # 确认人
    validate_user_id = db.Column(db.Integer, db.ForeignKey('customer_manager.id'), nullable=True)
    validate_user = db.relationship('CustomerManager')


class SubTask(db.Model):
    """翻译子任务"""

    __tablename__ = 'sub_task'

    id = db.Column(db.Integer, primary_key=True)
    # 主任务
    task_id = db.Column(db.Integer, db.ForeignKey('task.id'))
    task = db.relationship('Task', backref=db.backref('sub_task', order_by=id))

    name = db.Column(db.String(230))

    # 任务生成时间
    create_time = db.Column(db.DateTime)
    # 任务完成时间
    submit_time = db.Column(db.DateTime)
    # 确认时间
    validate_time = db.Column(db.DateTime, nullable=True)
    # 任务状态:-1 取消 0 待分配 1 已分配给local_manager或translation_agency 2 已分配给translator 3 待验证 4 已验证 5 已导出
    status = db.Column(db.Integer, default=0)
    # 子任务翻译进度
    progress = db.Column(db.Integer)
    # 已经翻译过的字串总数
    history_translated_count = db.Column(db.Integer, default=0)

    # 备注信息
    note = db.Column(db.String(200), nullable=True)

    # 翻译者，也就是任务执行者
    translator_id = db.Column(db.Integer, db.ForeignKey('translator.id'))
    translator = db.relationship('Translator', backref=db.backref('sub_task', order_by=id))

    # 客户local manager
    local_manager_id = db.Column(db.Integer, db.ForeignKey('customer_manager.id'))
    local_manager = db.relationship('CustomerManager', backref=db.backref('sub_task', order_by=id))

    #  翻译机构
    translation_agency_id = db.Column(db.Integer, db.ForeignKey('translate_agency.id'))
    translation_agency = db.relationship('TranslateAgency', backref=db.backref('sub_task', order_by=id))

    # 语言
    language_id = db.Column(db.Integer, db.ForeignKey('wmt_language.id'))
    language = db.relationship('Language', backref=db.backref('sub_task', order_by=id))

    # 本次任务所有的字串(已翻译和未翻译的)
    customer_wording = db.relationship(SubTaskCustomerWording, order_by=SubTaskCustomerWording.validate.desc())

    def __repr__(self):
        return "<SubTask %r>" % self.name