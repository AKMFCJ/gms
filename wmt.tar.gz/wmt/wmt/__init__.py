#-*- coding:utf-8 -*-
__author__ = 'changjie.fan'
"""应用初始化"""

import json
from flask import Flask
from flask.sessions import SecureCookieSession, SecureCookieSessionInterface
from flask.ext.mail import Mail
from flask.ext.moment import Moment
from flask.ext.sqlalchemy import SQLAlchemy
from flask.ext.login import LoginManager
from flask.ext.migrate import Migrate
from config import config


mail = Mail()
moment = Moment()
db = SQLAlchemy()


login_manager = LoginManager()
login_manager.session_protection = 'strong'
login_manager.login_view = 'auth.login'


class JSONSecureCookieSession(SecureCookieSession):
    serialization_method = json


class JSONSecureCookieSessionInterface(SecureCookieSessionInterface):
    session_class = JSONSecureCookieSession


def create_app(config_name):
    app = Flask(__name__)
    app.config.from_object(config[config_name])
    config[config_name].init_app(app)
    app.session_interface = JSONSecureCookieSessionInterface()

    mail.init_app(app)
    moment.init_app(app)
    db.init_app(app)
    login_manager.init_app(app)
    app.mail = mail
    if not app.debug and not app.testing and not app.config['SSL_DISABLE']:
        from flask.ext.sslify import SSLify
        sslify = SSLify(app)

    # 系统主入口
    from wmt.main import main as main_blueprint
    app.register_blueprint(main_blueprint)

    # 用户登陆/注销
    from wmt.auth import auth as auth_blueprint
    app.register_blueprint(auth_blueprint, url_prefix='/auth')

    # 项目管理
    from wmt.project import project as project_blueprint
    app.register_blueprint(project_blueprint, url_prefix='/project')

    # 客户管理
    from wmt.customer import customer as customer_blueprint
    app.register_blueprint(customer_blueprint, url_prefix='/customer')

    # 工程师模块
    from wmt.developer import developer as developer_blueprint
    app.register_blueprint(developer_blueprint, url_prefix='/developer')

    # 任务模块
    from wmt.task import task as task_blueprint
    app.register_blueprint(task_blueprint, url_prefix='/task')

    #  字符串模块
    from wmt.wording import wording as wording_blueprint
    app.register_blueprint(wording_blueprint, url_prefix='/wording')

    #  翻译者模块
    from wmt.translate import translate as translate_blueprint
    app.register_blueprint(translate_blueprint, url_prefix='/translate')

    #  翻译机构模块
    from wmt.translate_agency import translate_agency as translate_agency_blueprint
    app.register_blueprint(translate_agency_blueprint, url_prefix='/translate_agency')

    #  客户Global管理员模块
    from wmt.customer_manager import customer_manager as customer_manager_blueprint
    app.register_blueprint(customer_manager_blueprint, url_prefix='/customer_manager')

    #  客户local管理员模块
    from wmt.local_manager import local_manager as local_manager_blueprint
    app.register_blueprint(local_manager_blueprint, url_prefix='/local_manager')

    return app
