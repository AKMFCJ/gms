# -*- coding:utf-8 -*-
__author__ = 'changjie.fan'

""""""
from flask import Blueprint

translate_agency = Blueprint('translate_agency', __name__)
from . import views
