# -*- coding:utf-8 -*-
__author__ = 'changjie.fan'
"""
工程配置
"""

import os

base_dir = os.path.abspath(os.path.dirname(__file__))


class Config:
    SECRET_KEY = os.environ.get('SECRET_KEY') or 'tinno flask key'
    SSL_DISABLE = False
    SQLALCHEMY_COMMIT_ON_TEARDOWN = True
    SQLALCHEMY_RECORD_QUERIES = True
    MAIL_SERVER = 'smtp.tinno.com'
    MAIL_PORT = 25
    MAIL_USER_TLS = False
    MAIL_USERNAME = os.environ.get('MAIL_USERNAME')
    MAIL_PASSWORD = os.environ.get('MAIL_PASSWORD')
    WMT_MAIL_SUBJECT_PREFIX = '[WMT]'
    WMT_MAIL_SENDER = 'Tinno SCM<tinnoscm@tinno.com>'
    WMT_ADMIN = os.environ.get('WMT_ADMIN') or 'changjie.fan@tinno.com'
    WMT_POSTS_PER_PAGE = 20
    WMT_FOLLOWERS_PRE_PAGE = 50
    WMT_COMMENTS_PER_PAGE = 30
    WMT_SLOW_DB_QUERY_TIM = 0.5
    WMT_TEMP_DIR = os.path.join(base_dir, 'temp')
    WMT_STRING_TOOL = os.path.join(base_dir, 'StringTranslationTools', 'TranslationTools.zip')
    @staticmethod
    def init_app(app):
        pass


class DevelopmentConfig(Config):
    """开发环境配置"""

    DEBUG = True
    SQLALCHEMY_DATABASE_URI = os.environ.get('DEV_DATABASE_URL') or 'mysql://gms:gms@192.168.33.7:3306/wmt?charset=utf8'

    @classmethod
    def init_app(cls, app):
        Config.init_app(app)

        # 配置日志文件
        import logging
        import datetime

        logger = logging.getLogger('wmt')

        logging.basicConfig(
            level=logging.DEBUG,
            format='%(asctime)s %(name)s[line:%(lineno)d]:%(levelname)s %(message)s',
        )

        # 输出到文件
        log_file = os.path.join(base_dir, 'logs', datetime.datetime.now().strftime('%Y-%m-%d'), 'wmt.log')
        if not os.path.exists(os.path.dirname(log_file)):
            os.makedirs(os.path.dirname(log_file))

        file_handler = logging.FileHandler(log_file)
        file_handler.setLevel(logging.WARNING)
        logger.addHandler(file_handler)

        # 输出到控制台
        console_handler = logging.StreamHandler()
        console_handler.setLevel(logging.DEBUG)
        logger.addHandler(console_handler)
        logger.info('Developement')


class ProductionConfig(Config):
    """生产环境"""

    DEBUG = False
    SQLALCHEMY_DATABASE_URI = os.environ.get('DEV_DATABASE_URL') or 'mysql://gms:gms@192.168.33.7:3306/wmt?charset=utf8'


    @classmethod
    def init_app(cls, app):
        Config.init_app(app)

        cls.WMT_TEMP_DIR = '/var/www/tmp'
        # 配置日志文件
        import logging
        import datetime
        from logging.handlers import SMTPHandler

        logging.basicConfig(
            level=logging.DEBUG,
            format='%(asctime)s %(name)s[line:%(lineno)d]:%(levelname)s %(message)s',
        )

        # 输出到文件
        log_file = os.path.join(base_dir, 'logs', datetime.datetime.now().strftime('%Y-%m-%d'), 'wmt.log')
        if not os.path.exists(os.path.dirname(log_file)):
            os.makedirs(os.path.dirname(log_file))

        file_handler = logging.FileHandler(log_file)
        file_handler.setLevel(logging.WARNING)
        app.logger.addHandler(file_handler)

        # 输出到控制台
        console_handler = logging.StreamHandler()
        console_handler.setLevel(logging.DEBUG)
        app.logger.addHandler(console_handler)

        # 将系统错误邮件通知给管理员
        credentials = None
        secure = None
        if getattr(cls, 'MAIL_USERNAME', None) is not None:
            credentials = (cls.MAIL_USERNAME, cls.MAIL_PASSWORD)
            if getattr(cls, 'MAIL_USE_TLS', None):
                secure = ()

        mail_handler = SMTPHandler(
            mailhost=(cls.MAIL_SERVER, cls.MAIL_PORT),
            fromaddr=cls.WMT_MAIL_SENDER,
            toaddrs=[cls.WMT_ADMIN],
            subject=cls.WMT_MAIL_SUBJECT_PREFIX + 'Application Error',
            credentials=credentials,
            secure=secure,
        )
        mail_handler.setLevel(logging.ERROR)
        app.logger.addHandler(mail_handler)


config = {
    'production': ProductionConfig,
    'default': DevelopmentConfig,
}
