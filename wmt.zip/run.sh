#!/bin/bash

python manage.py runserver -t 192.168.33.137 -p 8000
