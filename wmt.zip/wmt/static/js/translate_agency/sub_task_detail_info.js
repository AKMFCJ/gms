var has_translated_wording_table;
var need_translate_wording_table;



jQuery(document).ready(function () {
    need_translate_wording_table = $('#need_translate_wording').DataTable({
        //dom: "Bfrtip",
        "language": {
            "aria": {
                "sortAscending": ": activate to sort column ascending",
                "sortDescending": ": activate to sort column descending"
            },
            "emptyTable": "No data available in table",
            "info": "Showing _START_ to _END_ of _TOTAL_ records",
            "infoEmpty": "No records found",
            "infoFiltered": "(filtered1 from _MAX_ total records)",
            "lengthMenu": "Show _MENU_ records",
            "search": "Search:",
            "zeroRecords": "No matching records found",
            "paginate": {
                "previous": "Prev",
                "next": "Next",
                "last": "Last",
                "first": "First"
            }
        },
        "bServerSide": true, // save datatable state(pagination, sort, etc) in cookie.
        "bProcessing": true,
        ajax: {
            url: '/local_manager/sub_task_need_translate_wording_data',
            data: {
                'sub_task_id': function () {
                    return window.sub_task_id;
                }
            }
        },
        columns: [
            {data: "no"},
            {data: "module_key"},
            {data: "description"},
            {data: "whole_string"},
            {data: "translated_value"}
        ],
        "lengthMenu": [
            [5, 20, 100, 200, 500],
            [5, 20, 100, 200, 500] // change per page values here
        ],
        // set the initial value
        "pageLength": 5,
        "pagingType": "bootstrap_full_number"
    });


/**********************************************************************************************************/
    has_translated_wording_table = $('#has_translated_wording').DataTable({
        "language": {
            "aria": {
                "sortAscending": ": activate to sort column ascending",
                "sortDescending": ": activate to sort column descending"
            },
            "emptyTable": "No data available in table",
            "info": "Showing _START_ to _END_ of _TOTAL_ records",
            "infoEmpty": "No records found",
            "infoFiltered": "(filtered1 from _MAX_ total records)",
            "lengthMenu": "Show _MENU_ records",
            "search": "Search:",
            "zeroRecords": "No matching records found",
            "paginate": {
                "previous": "Prev",
                "next": "Next",
                "last": "Last",
                "first": "First"
            }
        },
        "bServerSide": true, // save datatable state(pagination, sort, etc) in cookie.
        "bProcessing": true,
        "ajax": {
            url: '/local_manager/sub_task_has_translated_wording_data',
            data: {
                'sub_task_id': function () {
                    return window.sub_task_id;
                }
            },
        },
        columns: [
            {data: "no"},
            {data: "module_key"},
            {data: "description"},
            {data: "whole_string"},
            {data: "translated_value"}
        ],
        "lengthMenu": [
            [5, 20, 100, 200, 500],
            [5, 20, 100, 200, 500] // change per page values here
        ],
        // set the initial value
        "pageLength": 5,
        "pagingType": "bootstrap_full_number"
    });

/**********************************************************************************************************/
    //Show/hide columns dynamically
    var tableColumnToggler = $('#sample_4_column_toggler');
    /* handle show/hide columns*/
    $('input[type="checkbox"]', tableColumnToggler).change(function () {
        /* Get the DataTables object again - this is not a recreation, just a get of the object */
        var iCol = parseInt($(this).attr("data-column"));
        var bVis = $('#need_translate_wording').dataTable().fnSettings().aoColumns[iCol].bVisible;
        $('#need_translate_wording').dataTable().fnSetColumnVis(iCol, (bVis ? false : true));
        var bVis2 = $('#has_translated_wording').dataTable().fnSettings().aoColumns[iCol].bVisible;
        $('#has_translated_wording').dataTable().fnSetColumnVis(iCol, (bVis2 ? false : true));
    });
});