var TableManaged = function () {

    var initTable1 = function () {

        var table = $('#administrator_table');

        // begin first table
        table.dataTable({

            // Internationalisation. For more info refer to http://datatables.net/manual/i18n
            "language": {
                "aria": {
                    "sortAscending": ": activate to sort column ascending",
                    "sortDescending": ": activate to sort column descending"
                },
                "emptyTable": "No data available in table",
                "info": "Showing _START_ to _END_ of _TOTAL_ records",
                "infoEmpty": "No records found",
                "infoFiltered": "(filtered1 from _MAX_ total records)",
                "lengthMenu": "Show _MENU_ records",
                "search": "Search:",
                "zeroRecords": "No matching records found",
                "paginate": {
                    "previous": "Prev",
                    "next": "Next",
                    "last": "Last",
                    "first": "First"
                }
            },

            // Or you can use remote translation file
            //"language": {
            //   url: '//cdn.datatables.net/plug-ins/3cfcc339e89/i18n/Portuguese.json'
            //},

            // Uncomment below line("dom" parameter) to fix the dropdown overflow issue in the datatable cells. The default datatable layout
            // setup uses scrollable div(table-scrollable) with overflow:auto to enable vertical scroll(see: assets/global/plugins/datatables/plugins/bootstrap/dataTables.bootstrap.js). 
            // So when dropdowns used the scrollable div should be removed. 
            //"dom": "<'row'<'col-md-6 col-sm-12'l><'col-md-6 col-sm-12'f>r>t<'row'<'col-md-5 col-sm-12'i><'col-md-7 col-sm-12'p>>",

            "bStateSave": true, // save datatable state(pagination, sort, etc) in cookie.

            "columns": [{
                "orderable": false
            }, {
                "orderable": true
            }, {
                "orderable": false
            }, {
                "orderable": false
            }, {
                "orderable": true
            }, {
                "orderable": true
            }],
            "aoColumnDefs": [{
                sDefaultContent: '',
                aTargets: ['_all']
            }],
            "lengthMenu": [
                [15, 30, 60, -1],
                [15, 30, 60, "All"] // change per page values here
            ],
            // set the initial value
            "pageLength": 15,
            "pagingType": "bootstrap_full_number",
            "columnDefs": [{  // set default column settings
                'orderable': false,
                'targets': [0]
            }, {
                "searchable": false,
                "targets": [0]
            }],
            "order": [
                [1, "asc"]
            ] // set first column as a default sort by asc
        });

        var tableWrapper = jQuery('#administrator_table_wrapper');

        table.find('.group-checkable').change(function () {
            var set = jQuery(this).attr("data-set");
            var checked = jQuery(this).is(":checked");
            jQuery(set).each(function () {
                if (checked) {
                    $(this).attr("checked", true);
                    $(this).parents('tr').addClass("active");
                } else {
                    $(this).attr("checked", false);
                    $(this).parents('tr').removeClass("active");
                }
            });
            jQuery.uniform.update(set);
        });

        table.on('change', 'tbody tr .checkboxes', function () {
            $(this).parents('tr').toggleClass("active");
        });

        tableWrapper.find('.dataTables_length select').addClass("form-control input-xsmall input-inline"); // modify table per page dropdown

        $("#administrator_table tr").live({
            mouseover: function () {
                $(this).css("cursor", "pointer");
            }
        });
    }

    return {

        //main function to initiate the module
        init: function () {
            if (!jQuery().dataTable) {
                return;
            }

            initTable1();
        }

    };

}();

jQuery(document).ready(function () {
    TableManaged.init();
});

//table dbClick edit
$('#administrator_table tr').on("dblclick", function () {
    if ($(this).attr('data-role') == 'translator') {
        window.location.href = $SCRIPT_ROOT + '/auth/edit_account/' + $(this).attr('data-id');
    } else if ($(this).attr('data-role') == 'manager') {
        window.location.href = $SCRIPT_ROOT + '/auth/edit_customer_manager/' + $(this).attr('data-id');
    } else if ($(this).attr('data-role') == 'other') {
        window.location.href = $SCRIPT_ROOT + '/auth/edit_account/' + $(this).attr('data-id');
    }

});

// �޸��û�״̬
function change_user_status(user_id, status) {
    bootbox.confirm("Are you sure?", function (result) {
        if (result) {
            $.getJSON(
                $SCRIPT_ROOT + '/auth/change_user_status',
                {'user_id': user_id, 'status': status},
                function (data) {
                    if (status == 0) {
                        $('#dis_' + user_id).hide();
                        $('#enable_' + user_id).show();
                        $($('#tr_' + user_id).children()[5]).text('Disable')
                    } else {
                        $('#dis_' + user_id).show();
                        $('#enable_' + user_id).hide();
                        $($('#tr_' + user_id).children()[5]).text('Activate')
                    }
                }
            );
        }
    });
}