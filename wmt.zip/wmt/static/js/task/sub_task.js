
function table_init() {
    var task_wording_table = $('#task_wording').DataTable({
        "language": {
            "aria": {
                "sortAscending": ": activate to sort column ascending",
                "sortDescending": ": activate to sort column descending"
            },
            "emptyTable": "No data available in table",
            "info": "Showing _START_ to _END_ of _TOTAL_ records",
            "infoEmpty": "No records found",
            "infoFiltered": "(filtered1 from _MAX_ total records)",
            "lengthMenu": "Show _MENU_ records",
            "search": "Search:",
            "zeroRecords": "No matching records found",
            "paginate": {
                "previous": "Prev",
                "next": "Next",
                "last": "Last",
                "first": "First"
            }
        },
        "bServerSide": true, // save datatable state(pagination, sort, etc) in cookie.
        "bProcessing": true,
        "ajax": {
            url: '/task/sub_task_wording_data',
            data: {
                'sub_task_id': function () {
                    return window.sub_task_id;
                }
            },
        },
        "lengthMenu": [
            [10, 50, 200],
            [10, 50, 200] // change per page values here
        ],
        // set the initial value
        "pageLength": 10,
        "pagingType": "bootstrap_full_number"
    });
    return task_wording_table;
}

var sub_task_id;
var task_wording_table;


$('#current_task tbody').on( 'click', 'tr', function () {
    window.sub_task_id = $(this).attr('data');
    if (task_wording_table) {
        task_wording_table.ajax.reload();
    } else {
        task_wording_table = table_init();
    }
    $('#wording_title').text($(this).parent().find("td").eq(1).text()+"'s Wordings");
});

