# -*- coding:utf-8 -*-
__author__ = 'changjie.fan'

""""""

from datetime import datetime
import simplejson as json

from flask import render_template, redirect, url_for, request, flash, current_app, session
from flask.ext.login import login_required, current_user
from flask.ext.mail import Message

from wmt import db, mail
from . import customer_manager
from wmt.auth.models import User, Role
from wmt.customer.models import CustomerManager, Translator, customer_manager_language, Language, TranslateAgency
from wmt.task.models import Task, SubTask, SubTaskCustomerWording
from wmt.project.models import Project
from wmt.wording.models import WordingLanguageValue
from wmt.auth.util import new_account_email_notice


@customer_manager.route('/my_task')
@login_required
def my_task():
    """客户未分配、未确认的任务"""

    session['breadcrumbs'] = [session['breadcrumbs'][0]]
    session['breadcrumbs'].append({'text': 'MyTask', 'url': url_for('customer_manager.my_task')})
    session['menu_path'] = ['Task Manager', 'MyTask']

    current_app.logger.info(current_user.id)
    customer = CustomerManager.query.filter_by(id=current_user.id).first().customer
    # 正在翻译的、未分配的、翻译完成未确认的任务
    tasks = Task.query.join(Task.project).filter(
        db.and_(Project.customer == customer, Task.status.in_([0, 1, 2, 3, 4]))).all()
    for task in tasks:
        if task.status == 0:
            task.status_name = 'need assign'
        elif task.status == 1:
            task.status_name = 'has assign'
        elif task.status == 2:
            task.status_name = 'translating'
        elif task.status == 3:
            task.status_name = 'need validate'
        elif task.status == 4:
            task.status_name = 'need export'

    return render_template('/customer_manager/my_task_page.html', all_task=tasks)


@customer_manager.route('/translator_page')
@login_required
def translator_page():
    """翻译者账号管理"""

    session['breadcrumbs'] = [session['breadcrumbs'][0]]
    session['breadcrumbs'].append({'text': 'translator', 'url': url_for('customer_manager.translator_page')})
    session['menu_path'] = ['Account manager', 'translator']

    customer = CustomerManager.query.filter_by(id=current_user.id).first().customer
    translators = Translator.query.join(Translator.customer).filter(Translator.customer == customer).all()
    translators = [translator for translator in translators if not translator.translate_agency]

    return render_template('/customer_manager/translator_page.html', translators=translators)


@customer_manager.route('/add_translator', methods=['GET', 'POST'])
@login_required
def add_translator():
    """新增翻译账号"""

    for breadcrumb in session['breadcrumbs']:
        if 'New Translator' == breadcrumb['text']:
            break
    else:
        session['breadcrumbs'].append({'text': 'New Translator', 'url': url_for('customer_manager.add_translator')})

    if request.method == 'POST':
        username = request.form['username']
        email = request.form['email']
        password = request.form['password']
        password2 = request.form['password2']

        language_ids = request.form.getlist('language')

        other_translator = User.query.filter_by(email=email).first()
        if other_translator is not None:
            flash(u'This Email has registered', 'danger')
        else:
            if password != password2:
                flash(u'The two passwords do not match', 'danger')
            else:
                translator = Translator()
                translator.username = username
                translator.password = password
                translator.email = email
                translator.customer = CustomerManager.query.filter_by(id=current_user.id).first().customer

                for language in Language.query.filter(Language.id.in_(language_ids)):
                    translator.language.append(language)

                db.session.add(translator)
                db.session.commit()

                user = User.query.filter_by(id=translator.id).first()
                user.role = Role.query.filter_by(name='translator').first()

                db.session.add(user)
                db.session.commit()
                new_account_email_notice(request.url_root, translator.email, request.form['password'])
                flash(u'Success!', 'info')

    return render_template('/customer_manager/translator_edit.html',
                           translator=None, languages=Language.query.all())


@customer_manager.route('/edit_translator/<int:translator_id>', methods=['GET', 'POST'])
@login_required
def edit_translator(translator_id):
    """编辑翻译账号"""

    for breadcrumb in session['breadcrumbs']:
        if 'Edit Translator' == breadcrumb['text']:
            break
    else:
        session['breadcrumbs'].append({'text': 'Edit Translator',
                                       'url': url_for('customer_manager.edit_translator', translator_id=translator_id)})

    translator = Translator.query.filter_by(id=translator_id).first()

    if request.method == 'POST':
        username = request.form['username']
        email = request.form['email']
        password = request.form['password']
        password2 = request.form['password2']
        language_ids = request.form.getlist('language')

        other_translator = User.query.filter_by(email=email).first()
        if other_translator is not None and other_translator.id != translator.id:
            flash(u'This Email has registered', 'danger')
        else:
            if password != translator.password_hash and password != password2:
                flash(u'The two passwords do not match', 'danger')
            else:
                translator.username = username
                if translator.password_hash != password:
                    translator.password = password
                translator.email = email
                translator.customer = CustomerManager.query.filter_by(id=current_user.id).first().customer
                translator.language = []
                for language in Language.query.filter(Language.id.in_(language_ids)):
                    translator.language.append(language)

                db.session.add(translator)
                db.session.commit()

                flash(u'Success!', 'info')

    current_app.logger.info(translator.language)
    return render_template('/customer_manager/translator_edit.html',
                           translator=translator, languages=Language.query.all())


@customer_manager.route('/local_page')
@login_required
def local_page():
    """local Manager"""

    session['breadcrumbs'] = [session['breadcrumbs'][0]]
    session['breadcrumbs'].append({'text': 'Local Manager', 'url': url_for('customer_manager.local_page')})
    session['menu_path'] = ['Account manager', 'Local Manager']

    customer = CustomerManager.query.filter_by(id=current_user.id).first().customer
    managers = CustomerManager.query.join(CustomerManager.customer).join(Role).filter(db.and_(
        customer == customer,
        Role.name == 'local_manager',
    )).all()

    for manager in managers:
        manager.languages = ','.join([language.name for language in manager.language])

    return render_template('/customer_manager/local_page.html', managers=managers)


@customer_manager.route('/add_local', methods=['GET', 'POST'])
@login_required
def add_local():
    """新增管理员账号"""

    for breadcrumb in session['breadcrumbs']:
        if 'New Local Manager' == breadcrumb['text']:
            break
    else:
        session['breadcrumbs'].append({'text': 'New Local Manager', 'url': url_for('customer_manager.add_local')})

    if request.method == 'POST':
        username = request.form['username'].strip()
        email = request.form['email'].strip()
        password = request.form['password'].strip()
        password2 = request.form['password2'].strip()
        local_manager_language = request.form.get('local_manager_language', '').strip()

        other_manager = User.query.filter_by(email=email).first()
        current_app.logger.info(other_manager)
        if other_manager is not None:
            flash(u'This Email has registered', 'danger')
        else:
            if password != password2:
                flash(u'The two passwords do not match', 'danger')
            else:
                manager = CustomerManager()
                manager.username = username
                manager.password = password
                manager.email = email
                manager.language = Language.query.filter(Language.id.in_(local_manager_language)).all()
                manager.customer = CustomerManager.query.filter_by(id=current_user.id).first().customer

                db.session.add(manager)
                db.session.commit()

                user = User.query.filter_by(id=manager.id).first()
                user.role = Role.query.filter_by(name='local_manager').first()

                db.session.add(user)
                db.session.commit()

                flash(u'Success!', 'info')

    manager_languages = []
    for tmp in CustomerManager.query.all():
        manager_languages += tmp.language

    customer = CustomerManager.query.filter_by(id=current_user.id).first().customer
    languages = []
    for language in customer.language:
        if language not in manager_languages:
            languages.append(language)

    return render_template('/customer_manager/local_edit.html', manager=None, languages=languages)


@customer_manager.route('/edit_local/<int:local_id>', methods=['GET', 'POST'])
@login_required
def edit_local(local_id):
    """编辑翻译账号"""

    for breadcrumb in session['breadcrumbs']:
        if 'Edit Local Manager' == breadcrumb['text']:
            break
    else:
        session['breadcrumbs'].append({'text': 'Edit Local Manager',
                                       'url': url_for('customer_manager.edit_local', local_id=local_id)})

    manager = CustomerManager.query.filter_by(id=local_id).first()

    if request.method == 'POST':
        username = request.form['username'].strip()
        email = request.form['email'].strip()
        password = request.form['password'].strip()
        password2 = request.form['password2'].strip()
        local_manager_language = request.form.getlist('local_manager_language')
        current_app.logger.info(local_manager_language)
        other_manager = User.query.filter_by(email=email).first()
        if other_manager is not None and other_manager.id != manager.id:
            flash(u'This Email has registered', 'danger')
        else:
            if password != manager.password_hash and password != password2:
                flash(u'The two passwords do not match', 'danger')
            else:
                manager.username = username
                if manager.password_hash != password:
                    manager.password = password
                manager.email = email
                manager.customer = CustomerManager.query.filter_by(id=current_user.id).first().customer
                manager.language = Language.query.filter(Language.id.in_(local_manager_language)).all()
                db.session.add(manager)
                db.session.commit()

                flash(u'Success!', 'info')

    manager_languages = []
    for tmp in CustomerManager.query.all():
        manager_languages += tmp.language

    current_app.logger.info(manager_languages)
    languages = []
    for language in manager.customer.language:
        if language not in manager_languages:
            languages.append(language)

    return render_template('/customer_manager/local_edit.html', manager=manager, languages=languages)


@customer_manager.route('/assign_task_page/<int:task_id>', methods=['GET', 'POST'])
@login_required
def assign_task_page(task_id):
    """翻译任务分配页面"""

    for breadcrumb in session['breadcrumbs']:
        if 'Assign SubTask' == breadcrumb['text']:
            break
    else:
        session['breadcrumbs'].append({'text': 'Assign SubTask',
                                       'url': url_for('customer_manager.assign_task_page', task_id=task_id)})

    if request.method == 'POST':
        sub_task_id = request.form.get('assign_task', '')
        sub_task_own_id = request.form.get('sub_task_own', '')
        current_app.logger.info(sub_task_own_id)

        sub_task = SubTask.query.filter_by(id=sub_task_id).first()

        # 分配local manager
        if sub_task_own_id.startswith('local_manger#'):
            sub_task_own_id = sub_task_own_id.split('#')[1]
            task_local_manager = CustomerManager.query.filter_by(id=sub_task_own_id).first()
            sub_task.local_manager = task_local_manager
            sub_task_own = task_local_manager
        else:
            sub_task_own_id = sub_task_own_id.split('#')[1]
            # 分配翻译机构
            task_translation_agency = TranslateAgency.query.filter_by(user_id=sub_task_own_id).first()
            sub_task.translation_agency = task_translation_agency
            # 分配语言对应的local manger 在翻译完成后做validate工作
            all_local_manager = CustomerManager.query.filter(
                CustomerManager.customer == task_translation_agency.customer).all()
            for local_manger in all_local_manager:
                if sub_task.language in local_manger.language:
                    sub_task.local_manager = local_manger
                    break
            else:
                flash(u'There has not this language local manger', 'danger')
                return redirect(url_for('customer_manager.assign_task_page', task_id=task_id))

            sub_task_own = task_translation_agency.user

        sub_task.status = 1
        db.session.add(sub_task)
        db.session.commit()

        # 给Local Manager或translation_agency发生通知邮件
        msg = Message(
            '[WMT]New Translate Task %s' % sub_task.name,
            sender='Tinno@tinno.com',
            recipients=[sub_task_own.email]
        )
        msg.body = "You has new Translate task\n %s" % sub_task.name
        mail.send(msg)

    task = Task.query.filter_by(id=task_id).first()
    sub_tasks = SubTask.query.filter(SubTask.task_id == task_id).all()
    need_assign_tasks = []
    has_assign_tasks = []
    for sub_task in sub_tasks:
        if sub_task.status == -1 or sub_task.status == 0:
            need_assign_tasks.append(sub_task)
        else:
            if sub_task.status == -1:
                sub_task.status_name = 'cancel'
            elif sub_task.status == 0:
                sub_task.status_name = 'need assign'
            elif sub_task.status == 1:
                sub_task.status_name = 'has assign'
            elif sub_task.status == 2:
                sub_task.status_name = 'translating'
            elif sub_task.status == 3:
                sub_task.status_name = 'need validate'
            elif sub_task.status == 4:
                sub_task.status_name = 'complete'

            has_assign_tasks.append(sub_task)

    # 所有子任务都已分配
    if not need_assign_tasks:
        task.status = 1
        db.session.add(task)
        db.session.commit()
        # 给任务创建者发送邮件提醒当前任务进度
        msg = Message(
            '[WMT]Task assign',
            sender='Tinno@tinno.com',
            recipients=[task.creator.email]
        )
        msg.body = "%s has assign to local_manager or translation agency" % task.name
        mail.send(msg)

    session['task_id'] = task_id

    local_manager = CustomerManager.query.join(Role).filter(db.and_(
        CustomerManager.customer_id == task.project.customer_id, Role.name == 'local_manager',
        CustomerManager.activate == True)).all()

    translate_agency_record = TranslateAgency.query.filter(
        db.and_(TranslateAgency.customer_id == task.project.customer_id, TranslateAgency.activate == True)).all()

    for sub_task in need_assign_tasks:
        for local_manager_obj in local_manager:
            if sub_task.language in local_manager_obj.language:
                sub_task.local_manager_language = str(local_manager_obj.id) + '#' + local_manager_obj.username
                break
        for agency_obj in translate_agency_record:
            if sub_task.language in agency_obj.language:
                sub_task.translation_agency_language = str(agency_obj.user.id) + '#' + agency_obj.user.username
                break

    return render_template('/customer_manager/assign_to_local_manager.html',
                           task=task,
                           need_assign_tasks=need_assign_tasks,
                           has_assign_tasks=has_assign_tasks)


@customer_manager.route('/cancel_sub_task/<int:sub_task_id>', methods=['POST', 'GET'])
@login_required
def cancel_sub_task(sub_task_id):
    """取消分给local manager的子任务"""

    sub_task = SubTask.query.filter_by(id=sub_task_id).first()

    sub_task.status = 0
    sub_task.local_manager = None
    sub_task.translation_agency = None
    db.session.add(sub_task)
    if sub_task.task.status == 1:
        sub_task.task.status = 0
        db.session.add(sub_task.task)
    db.session.commit()

    if sub_task.local_manager:
        # 给Local Manager发生通知邮件
        msg = Message(
            '[WMT]Cancel %s Task' % sub_task.name,
            sender='Tinno@tinno.com',
            recipients=[sub_task.local_manager.email]
        )
        msg.body = "Task {0} cancel by {1}".format(sub_task.name, current_user.email)
        # msg.send()

    return redirect(url_for('customer_manager.assign_task_page', task_id=session['task_id']))


@customer_manager.route('/sub_task_page/<int:task_id>')
@login_required
def sub_task_page(task_id):
    """主任务的所有子任务"""

    for breadcrumb in session['breadcrumbs']:
        if 'SubTask' == breadcrumb['text']:
            break
    else:
        session['breadcrumbs'].append({'text': 'SubTask', 'url': url_for('customer_manager.sub_task_page', task_id=task_id)})

    sub_tasks = SubTask.query.filter_by(task_id=task_id).all()
    task_obj = Task.query.filter_by(id=task_id).first()
    for sub_task in sub_tasks:
        if sub_task.status == 0:
            sub_task.status_name = 'need assign'
        elif sub_task.status == 1:
            sub_task.status_name = 'has assign'
        elif sub_task.status == 2:
            sub_task.status_name = 'translating'
        elif sub_task.status == 3:
            sub_task.status_name = 'need validate'
        elif sub_task.status == 4:
            sub_task.status_name = 'need export'
        elif sub_task.status == -1:
            sub_task.status_name = 'cancel'

    return render_template('customer_manager/sub_task_page.html', task=task_obj, sub_tasks=sub_tasks)


@customer_manager.route('/approve_wording/<int:task_id>')
@login_required
def approve_wording(task_id):
    """
    主任务的所有子任务
    及待确认的字符
    """

    sub_tasks = SubTask.query.filter_by(task_id=task_id).all()
    task_obj = sub_tasks[0].task

    wording_sql = "SELECT sub_task.id, c_w.id, sub_task.name, wording.path, wording.name, wording.description, " \
                  "wording.whole_string, s_t_c_w.translated_value FROM sub_task JOIN task ON " \
                  "sub_task.task_id=task.id JOIN sub_task_customer_wording AS s_t_c_w ON " \
                  "sub_task.id=s_t_c_w.sub_task_id JOIN customer_wording AS c_w ON c_w.id=s_t_c_w.customer_wording_id " \
                  "JOIN wording ON c_w.wording_id=wording.id WHERE task.id={0} AND s_t_c_w.validate=4;".format(task_id)

    current_app.logger.info(wording_sql)
    wordings = [
        {'sub_task_id': wording[0],
         'customer_wording_id': wording[1],
         'sub_task_name': wording[2],
         'module': wording[3],
         'key': wording[4],
         'description': wording[5],
         'whole_string': wording[6],
         'translated_value': wording[7]
         }
        for wording in db.session.execute(wording_sql).fetchall()]

    return render_template('customer_manager/approve_wording_page.html', task=task_obj,
                           sub_tasks=sub_tasks,
                           wordings=wordings)


@customer_manager.route('/validate_wording', methods=['GET', 'POST'])
@login_required
def validate_wording():
    """验证字串的翻译结果"""

    sub_task_id = request.form['sub_task_id']
    customer_wording_id = request.form['wording_id']
    status = request.form['status']
    refuse_msg = request.form.get('refuse_msg', '')

    wording = SubTaskCustomerWording.query.filter(
        db.and_(SubTaskCustomerWording.sub_task_id == sub_task_id,
                SubTaskCustomerWording.customer_wording_id == customer_wording_id)).first()
    wording.validate = int(status)
    wording.validate_time = datetime.now()
    wording.validate_msg = refuse_msg.strip()
    wording.validate_user = CustomerManager.query.filter(CustomerManager.id == current_user.id).first()

    sub_task = SubTask.query.filter_by(id=sub_task_id).first()
    if status == '-1':
        db.session.add(wording)
        sub_task.status = 0
        db.session.add(sub_task)
        db.session.commit()
    else:
        customer_wording_value = WordingLanguageValue.query.filter(
            db.and_(WordingLanguageValue.customer_wording_id == wording.customer_wording.id,
                    WordingLanguageValue.language_id == sub_task.language_id)).first()
        if customer_wording_value:
            if customer_wording_value.translated_value != wording.translated_value:
                customer_wording_value.translated_value = wording.translated_value
                customer_wording_value.size = len(wording.translated_value)
                customer_wording_value.translated_time = datetime.now()
                customer_wording_value.sub_task = sub_task
                db.session.add(customer_wording_value)
        else:
            customer_wording_value = WordingLanguageValue()
            customer_wording_value.customer_wording = wording.customer_wording
            customer_wording_value.translated_value = wording.translated_value
            customer_wording_value.size = len(wording.translated_value)
            customer_wording_value.translated_time = datetime.now()
            customer_wording_value.sub_task = sub_task
            customer_wording_value.language = sub_task.language
            db.session.add(customer_wording_value)

        db.session.add(wording)
        db.session.commit()

        wording_count = SubTaskCustomerWording.query.filter(
            db.and_(SubTaskCustomerWording.sub_task_id == sub_task_id,
                    db.or_(SubTaskCustomerWording.validate == 0, SubTaskCustomerWording.validate == -1))).count()

        # 判断子任务的所有的字串是否都通过确认,来设置子任务的状态
        if wording_count == 0:
            sub_task.status = 2
            sub_task.validate_time = datetime.now()
            db.session.add(sub_task)
            db.session.commit()

            # 判断主任务是否都通过确认
            sub_task_count = SubTask.query.filter(
                db.and_(SubTask.task_id == sub_task.task_id, SubTask.status == 0)).count()
            if sub_task_count == 0:
                master_task = sub_task.task
                master_task.status = 1
                master_task.submit_time = datetime.now()
                db.session.add(master_task)
                db.session.commit()
                # 通知开发其任务已经翻译完成
                msg = Message(
                    '[WMT]Task %s has translated complete' % master_task.name,
                    sender='Tinno@tinn.com',
                    recipients=[master_task.creator.email]
                )
                msg.body = "Please validate this task"
                mail.send(msg)

        # 判断是否有其他子任务中包含了相同字串，相同语言的待验证任务
        other_task_wording = wording = SubTaskCustomerWording.query.filter(
            db.and_(SubTaskCustomerWording.sub_task_id != sub_task_id,
                    SubTaskCustomerWording.customer_wording_id == customer_wording_id)).first()
        if other_task_wording:
            other_sub_task = SubTask.query.filter(
                db.and_(SubTask.id == other_task_wording.sub_task_id,
                        SubTask.language_id == sub_task.language_id)).first()
            if other_sub_task:
                other_task_wording.validate = int(status)
                other_task_wording.validate_time = datetime.now()
                other_task_wording.validate_msg = refuse_msg.strip()
                other_task_wording.validate_user = CustomerManager.query.filter(CustomerManager.id == current_user.id).first()
                db.session.add(other_task_wording)
                db.session.commit()

                # 判断其他子任务及主任务是否翻译完成
                other_wording_count = SubTaskCustomerWording.query.filter(
                    db.and_(SubTaskCustomerWording.sub_task_id == other_sub_task.id,
                            db.or_(SubTaskCustomerWording.validate == 0, SubTaskCustomerWording.validate == -1))).count()

                # 判断子任务的所有的字串是否都通过确认,来设置子任务的状态
                if other_wording_count == 0:
                    other_sub_task.status = 2
                    other_sub_task.validate_time = datetime.now()
                    db.session.add(other_sub_task)
                    db.session.commit()

                    # 判断主任务是否都通过确认
                    other_sub_task_count = SubTask.query.filter(
                        db.and_(SubTask.task_id == other_sub_task.task_id, SubTask.status == 0)).count()
                    if other_sub_task_count == 0:
                        master_task = other_sub_task_count.task
                        master_task.status = 1
                        master_task.submit_time = datetime.now()
                        db.session.add(master_task)
                        db.session.commit()
                        # 通知开发其任务已经翻译完成
                        msg = Message(
                            '[WMT]Task %s has translated complete' % master_task.name,
                            sender='Tinno@tinn.com',
                            recipients=[master_task.creator.email]
                        )
                        msg.body = "Please validate this task"
                        mail.send(msg)

    return json.dumps({'success': 'true'})


@customer_manager.route('/wording_search')
@login_required
def wording_search():
    """字符串检索"""

    search_type = request.args.get('search_type', '').strip()
    search = request.args.get('search', '').strip()
    result = []

    if search_type and search:
        wording_sql = "SELECT wording.path, wording.name AS wording_name, wording.whole_string, " \
                      "c_w_v.translated_value, w_l.name AS language_name, customer.name AS customer_name, " \
                      "wmt_user.username AS username, sub_task.name AS sub_task_name, sub_task.submit_time " \
                      "FROM wording JOIN customer_wording AS c_w ON wording.id=c_w.wording_id JOIN customer ON " \
                      "customer.id=c_w.customer_id JOIN customer_wording_language_value AS c_w_v ON " \
                      "c_w.id=c_w_v.customer_wording_id JOIN wmt_language AS w_l ON c_w_v.language_id=w_l.id " \
                      "JOIN sub_task ON c_w_v.sub_task_id=sub_task.id JOIN translator ON " \
                      "sub_task.translator_id=translator.id JOIN wmt_user ON wmt_user.id=translator.id " \
                      "WHERE {0} like '%%{1}%%'".format(search_type, search)

        current_app.logger.info(wording_sql)
        wordings = db.session.execute(wording_sql).fetchall()

        index = 1
        for wording in wordings:
            result.append({
                'index': index,
                'path': wording[0],
                'name': wording[1],
                'whole_string': wording[2],
                'translated_value': wording[3],
                'language': wording[4],
                'customer_name': wording[5],
                'sub_task_name': wording[6],
                'translator': wording[7],
                'submit_time': wording[8],
            })
            index += 1

    return render_template('developer/wording_search_page.html', search_type=search_type, search=search, wordings=result)


@customer_manager.route('/sub_task_wording_page/<int:sub_task_id>', methods=['GET', 'POST'])
@login_required
def sub_task_wording_page(sub_task_id):
    """子任务翻译和为翻译的字串页面"""

    for breadcrumb in session['breadcrumbs']:
        if 'SubTask Wording' == breadcrumb['text']:
            break
    else:
        session['breadcrumbs'].append({'text': 'SubTask Wording',
                                       'url': url_for('customer_manager.sub_task_wording_page',
                                                      sub_task_id=sub_task_id)})

    sub_task = SubTask.query.filter_by(id=sub_task_id).first()

    return render_template('customer_manager/sub_task_wording.html', sub_task=sub_task)


@customer_manager.route('/translate_agency')
@login_required
def translate_agency():
    """翻译代理"""

    session['breadcrumbs'] = [session['breadcrumbs'][0]]
    session['breadcrumbs'].append({'text': 'Translate Agency', 'url': url_for('customer_manager.translate_agency')})
    session['menu_path'] = ['Account manager', 'translate agency']

    customer = CustomerManager.query.filter_by(id=current_user.id).first().customer
    agency = TranslateAgency.query.filter(customer == customer).all()

    for agency_record in agency:
        agency_record.languages = ','.join([language.name for language in agency_record.language])

    return render_template('/customer_manager/translate_agency_page.html', agency=agency)


@customer_manager.route('/add_translate_agency', methods=['GET', 'POST'])
@login_required
def add_translate_agency():
    """新增管理员账号"""

    for breadcrumb in session['breadcrumbs']:
        if 'New Translate Agency' == breadcrumb['text']:
            break
    else:
        session['breadcrumbs'].append({'text': 'New Translate Agency',
                                       'url': url_for('customer_manager.add_translate_agency')})

    customer = CustomerManager.query.filter_by(id=current_user.id).first().customer

    if request.method == 'POST':
        name = request.form['name'].strip()
        username = request.form['username'].strip()
        email = request.form['email'].strip()
        password = request.form['password'].strip()
        password2 = request.form['password2'].strip()
        language = request.form.getlist('agency_manager_language')

        other_user = User.query.filter_by(email=email).first()
        other_agency = TranslateAgency.query.filter(db.and_(TranslateAgency.customer == customer,
                                                      TranslateAgency.name == name)).first()

        if other_user is not None:
            flash(u'This Email has registered', 'danger')
        elif other_agency is not None:
            flash(u'This Name has registered', 'danger')
        else:
            if password != password2:
                flash(u'The two passwords do not match', 'danger')
            else:
                user = User()
                user.username = username
                user.password = password
                user.email = email
                user.role = Role.query.filter_by(name='translate_agency').first()
                db.session.add(user)
                db.session.commit()

                agency = TranslateAgency()
                agency.name = name
                agency.language = Language.query.filter(Language.id.in_(language)).all()
                agency.customer = customer
                agency.user = user

                db.session.add(agency)
                db.session.commit()
                new_account_email_notice(request.url_root, user.email, request.form['password'])
                flash(u'Success!', 'info')

    manager_languages = []
    for tmp in TranslateAgency.query.all():
        manager_languages += tmp.language

    languages = []

    for language in customer.language:
        if language not in manager_languages:
            languages.append(language)

    return render_template('/customer_manager/translate_agency_edit.html', agency=None, languages=languages)


@customer_manager.route('/edit_translate_agency/<int:agency_id>', methods=['GET', 'POST'])
@login_required
def edit_translate_agency(agency_id):
    """编辑翻译账号"""

    for breadcrumb in session['breadcrumbs']:
        if 'Edit Translate Agency' == breadcrumb['text']:
            break
    else:
        session['breadcrumbs'].append({'text': 'Edit Translate Agency',
                                       'url': url_for('customer_manager.edit_translate_agency', agency_id=agency_id)})

    customer = CustomerManager.query.filter_by(id=current_user.id).first().customer
    agency = TranslateAgency.query.filter_by(id=agency_id).first()

    if request.method == 'POST':
        name = request.form['name'].strip()
        username = request.form['username'].strip()
        email = request.form['email'].strip()
        password = request.form['password'].strip()
        password2 = request.form['password2'].strip()
        agency_language = request.form.getlist('agency_manager_language')
        has_error = False

        if password != password2:
            flash(u'The two passwords do not match', 'danger')
            has_error = True

        if not has_error and agency.name != name:
            other_agency = TranslateAgency.query.filter(db.and_(TranslateAgency.customer == customer,
                                                                TranslateAgency.name == name)).first()
            current_app.logger.info(customer)
            current_app.logger.info(name)
            current_app.logger.info(other_agency)
            if other_agency is not None and other_agency.id != agency.id:
                flash(u'This %s name in use. Please Chang it' % name, 'danger')
                has_error = True
        if not has_error and agency.user.email != email:
            other_manager = User.query.filter_by(email=email).first()
            if other_manager is not None and other_manager.id != agency.user.id:
                flash(u'This Email has registered', 'danger')
                has_error = True
        if not has_error:
            agency.user.username = username
            if agency.user.password_hash != password:
                agency.user.password = password
            agency.user.email = email
            db.session.add(agency.user)

            agency.name = name
            agency.customer = customer
            agency.language = Language.query.filter(Language.id.in_(agency_language)).all()
            db.session.add(agency)
            db.session.commit()

            flash(u'Success!', 'info')

    manager_languages = []
    for tmp in TranslateAgency.query.all():
        manager_languages += tmp.language

    languages = []
    for language in customer.language:
        if language not in manager_languages:
            languages.append(language)

    return render_template('/customer_manager/translate_agency_edit.html', agency=agency, languages=languages)
