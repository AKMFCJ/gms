# -*- coding:utf-8 -*-
__author__ = 'changjie.fan'

"""定义客户管理员模块的蓝图"""
from flask import Blueprint

customer_manager = Blueprint('customer_manager', __name__)
from . import views
