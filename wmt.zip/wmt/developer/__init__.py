# -*- coding:utf-8 -*-
__author__ = 'changjie.fan'

""""""
from flask import Blueprint

developer = Blueprint('developer', __name__)
from . import views
