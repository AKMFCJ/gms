# -*- coding:utf-8 -*-
__author__ = 'changjie.fan'

"""任务模块的蓝图"""
from flask import Blueprint

task = Blueprint('task', __name__)
from . import views
