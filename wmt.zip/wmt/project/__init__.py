# -*- coding:utf-8 -*-
__author__ = 'changjie.fan'

"""定义项目模块的蓝图"""

from flask import Blueprint


project = Blueprint('project', __name__)
from . import views
