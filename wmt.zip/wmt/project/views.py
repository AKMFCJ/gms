# -*- coding:utf-8 -*-

__author__ = 'roy'
__created__ = '11/18/15'

""""""
import simplejson as json
from flask import render_template, redirect, url_for, request, flash, current_app, session
from flask.ext.login import login_required, current_user

from . import project
from models import Project
from wmt import db
from wmt.auth.models import User, Role
from wmt.customer.models import Customer, Language


@project.route('/project_page')
@login_required
def my_project():
    """
    我的项目页面
    当前用户是负责人和参与的项目
    超级管理员显示所有项目
    """

    session['breadcrumbs'] = [session['breadcrumbs'][0]]
    session['breadcrumbs'].append({'text': 'MyProject', 'url': url_for('project.my_project')})
    session['menu_path'] = ['Project Manager', 'MyProject']

    if current_user.role.name == 'admin':
        my_project_obj = Project.query.all()
    else:
        my_project_obj = Project.query.filter_by(develop_lead=current_user).all()
        member_project = Project.query.join(User.project_m).filter(User.id == current_user.id).all()
        for project_obj in member_project:
            if project_obj not in my_project_obj:
                my_project_obj.append(project_obj)

    return render_template('/project/my_project_page.html', projects=my_project_obj)


@project.route('/add_project', methods=['GET', 'POSt'])
@login_required
def add_project():
    """新增"""

    for breadcrumb in session['breadcrumbs']:
        if 'New Project' == breadcrumb['text']:
            break
    else:
        session['breadcrumbs'].append({'text': 'New Project', 'url': url_for('project.add_project')})

    project_obj = None

    if request.method == 'POST':
        name = request.form['name']
        platform_vendor = request.form['platform']
        develop_lead_id = int(request.form['develop_lead'])
        members = request.form.getlist('member')
        customer_id = int(request.form['customer'])

        other_project = Project.query.filter_by(name=name).first()

        if other_project is not None:
            flash(u'相同名称的项目已存在', 'danger')
        else:
            project_obj = Project()
            project_obj.name = name
            project_obj.platform_vendor = platform_vendor
            project_obj.develop_lead = User.query.filter_by(id=develop_lead_id).first()
            customer = Customer.query.filter_by(id=customer_id).first()
            project_obj.customer = customer
            project_obj.members = User.query.filter(User.id.in_(members)).all()

            db.session.add(project_obj)
            db.session.commit()

            flash(u'新增成功!', 'info')

    customers = Customer.query.all()

    return render_template('/project/project_edit.html',
                           project=project_obj, users=User.query.join(User.role).filter(Role.name == 'developer').all(),
                           customers=customers)


@project.route('/edit_project/<int:project_id>', methods=['GET', 'POSt'])
@login_required
def edit_project(project_id):
    """编辑"""

    for breadcrumb in session['breadcrumbs']:
        if 'Edit Project' == breadcrumb['text']:
            break
    else:
        session['breadcrumbs'].append({'text': 'Edit Project',
                                       'url': url_for('project.edit_project', project_id=project_id)})

    project_obj = Project.query.filter_by(id=project_id).first()

    if request.method == 'POST':
        name = request.form['name']
        platform_vendor = request.form['platform']
        develop_lead_id = int(request.form['develop_lead'])
        members = request.form.getlist('member')
        customer_id = int(request.form['customer'])

        other_project = Project.query.filter_by(name=name).first()

        if other_project is not None and other_project.id != project_id:
            flash(u'相同名称的项目已存在', 'danger')
        else:
            project_obj.name = name
            project_obj.platform_vendor = platform_vendor
            project_obj.develop_lead = User.query.filter_by(id=develop_lead_id).first()
            customer = Customer.query.filter_by(id=customer_id).first()
            project_obj.customer = customer
            project_obj.members = User.query.filter(User.id.in_(members)).all()

            db.session.add(project_obj)
            db.session.commit()

            flash(u'修改成功!', 'info')

    return render_template('/project/project_edit.html',
                           project=project_obj, users=User.query.join(User.role).filter(Role.name=='developer').all(),
                           customers=Customer.query.all())


@project.route('/get_customer_language')
@login_required
def get_customer_language():
    """获取项目所属客户的语言集合"""

    project_id = request.args.get('project_id')
    all_language = []

    for language in Project.query.filter_by(id=int(project_id)).first().customer.language:
        all_language.append({'id': language.id, 'name': '{0}[{1}]'.format(language.name, language.abbreviation)})

    return json.dumps(all_language)

