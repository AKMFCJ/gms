# -*- coding:utf-8 -*-

__author__ = 'roy'
__created__ = '11/18/15'

""""""

from wmt import db


project_member = db.Table('project_member', db.metadata,
                          db.Column('user_id', db.Integer, db.ForeignKey('wmt_user.id')),
                          db.Column('project_id', db.Integer, db.ForeignKey('project.id')))


class Project(db.Model):
    """项目模块"""

    __tablename__ = 'project'

    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False, unique=True)
    platform_vendor = db.Column(db.String(10))
    task_count = db.Column(db.Integer, default=0)
    # Green all key value validated/Red all key must translate/Orange key must be validated/Black new project
    status = db.Column(db.String(10), default='black')
    develop_lead_id = db.Column(db.Integer, db.ForeignKey('wmt_user.id'))
    develop_lead = db.relationship('User', backref=db.backref('project', order_by=id))
    members = db.relationship('User', secondary='project_member', backref='project_m')
    customer_id = db.Column(db.Integer, db.ForeignKey('customer.id'))
    customer = db.relationship('Customer', backref=db.backref('project', order_by=id))

    def __repr__(self):
        return "<Project %r>" % self.name


class ProjectNotice(db.Model):
    """
    项目通知
    1. 同一客户的其他项目修改了相同的key值字符串，之前翻译过此字符串的项目的开发负责人和项目组成员，也会得到通知信息
    2. 客户自己修改了字符串翻译，所有包含此字串的项目也会得到通知
    """

    __tablename__ = 'project_notice'

    id = db.Column(db.Integer, primary_key=True)
    create_date = db.Column(db.DateTime)
    info = db.Column(db.String(500))
    # 0未处理 1 已处理 2 已忽略
    status = db.Column(db.Integer)

    project_id = db.Column(db.Integer, db.ForeignKey('project.id'))
    project = db.relationship('Project', backref=db.backref('project', order_by=id))

    def __repr__(self):
        return "<ProjectNotice %r>" % self.project.name
