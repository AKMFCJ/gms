# -*- coding:utf-8 -*-
__author__ = 'changjie.fan'

""""""
import os

from wmt import db, mail
from flask.ext.mail import Message

class MenuObject:
    def __init__(self, id, name, url, style):
        self.id = id
        self.name = name
        self.url = url
        self.style = style
        self.children = []


def create_menu(menus):
    """创建默认菜单"""

    parents = []
    for menu in menus:
        if not menu.parent_id:
            parents.append({'id': menu.id, 'name': menu.name, 'url': menu.action, 'style': menu.style,
                            'children': []})
    for menu in menus:
        if menu.parent_id:
            for parent in parents:
                if parent['id'] == menu.parent_id:
                    parent['children'].append({'id': menu.id, 'name': menu.name, 'url': menu.action,
                                               'style': menu.style, 'children': []})

    return parents


def new_account_email_notice(url, user_email, password):
    """给新增的账号，发邮件通知，告知其用户名和密码以及登陆地址"""

    # 给Local Manager或translation_agency发生通知邮件
    msg = Message(
        "[WMT]Weclome use this System",
        sender='Tinno@tinno.com',
        recipients=[user_email]
    )
    msg.html = "Url:{0}<br>Username:{1}<br>Password:{2}".format(url, user_email, password)
    mail.send(msg)
