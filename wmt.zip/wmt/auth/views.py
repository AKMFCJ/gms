# -*- coding:utf-8 -*-
__author__ = 'changjie.fan'

""""""
from datetime import datetime
import simplejson as json
from flask import render_template, redirect, url_for, request, flash, current_app, jsonify, g, session
from flask.ext.login import login_user, logout_user, login_required

from forms import LoginForm, ChangePasswordForm, ChangeEmailForm
from models import User, Role, SystemMenu
from wmt.customer.models import Translator, Language, Customer, CustomerManager, TranslateAgency
from . import auth
from wmt import db
from util import create_menu, new_account_email_notice


@auth.route('/login', methods=['GET', 'POST'])
def login():
    """用户登录"""

    if request.method == 'POST':
        user = User.query.filter_by(email=request.form['email']).first()

        if user:
            if not user.activate:
                flash('Your Account has disable.', 'danger')
            elif user.verify_password(request.form['password']):
                login_user(user, request.form.get('remember'))
                user.last_seen = datetime.now()
                role = user.role
                menu_id = [int(id) for id in role.menu.split(',') if id]
                current_app.logger.info(menu_id)
                menus = [menu for menu in SystemMenu.query.filter(db.and_(SystemMenu.activate == True,
                                                        SystemMenu.id.in_(menu_id))).order_by(SystemMenu.order).all()]

                session['user'] = {'id': user.id, 'username': user.username, 'email': user.email}
                session['index_page'] = role.index_page
                session['menu'] = create_menu(menus)
                session['breadcrumbs'] = [{'text': 'Home', 'url': url_for(role.index_page)}]

                return redirect(url_for(role.index_page))
            else:
                flash('Invalid email or password.', 'danger')
        else:
            flash('Email not exists', 'danger')

    return render_template('auth/login.html')


@auth.route('/logout')
@login_required
def logout():
    """用户登出"""

    logout_user()
    flash('You have been logged out.', 'info')
    return redirect(url_for('auth.login'))


@auth.route('/settings', methods=['GET', 'POST'])
@login_required
def settings():
    """账号设置设置"""
    password_form = ChangePasswordForm()
    email_form = ChangeEmailForm()

    return render_template('auth/settings.html', password_form=password_form, email_form=email_form,
                           url_path=session['menu_path']['auth.settings'],
                           current_page='auth.settings')


@auth.route('/change_email', methods=['POST'])
@login_required
def change_email():
    data = json.loads(request.form.get('data'))
    return str(data['email'])


@auth.route('/account_page')
@login_required
def account_page():
    session['breadcrumbs'] = [session['breadcrumbs'][0]]
    session['breadcrumbs'].append({'text': 'Account_manager', 'url': url_for('auth.account_page')})
    session['menu_path'] = ['系统管理', '账号管理']
    return render_template('admin/account/account_page.html', users=User.query.all())


@auth.route('/add_account', methods=['GET', 'POST'])
@login_required
def add_account():
    """新增账号"""
    for breadcrumb in session['breadcrumbs']:
        if 'New Account' == breadcrumb['text']:
            break
    else:
        session['breadcrumbs'].append({'text': 'New Account', 'url': url_for('auth.add_account')})

    new_user = None
    if request.method == 'POST':
        if request.form['password'] != request.form['password2']:
            flash(u'两次输入的密码不相同', 'danger')
            return redirect(url_for('auth.add_account'))

        user = User.query.filter_by(email=request.form['email']).first()
        if user is not None:
            flash(u'此邮箱地址已注册过', 'danger')
            return redirect(url_for('auth.add_account'))

        new_user = User()
        new_user.username = request.form['username']
        new_user.email = request.form['email']
        new_user.password = request.form['password']
        new_user.role = Role.query.filter_by(id=request.form['role']).first()

        db.session.add(new_user)
        db.session.commit()

        new_account_email_notice(request.url_root, new_user.email, request.form['password'])
        flash(u'新增成功', 'info')
        return redirect(url_for('auth.add_account'))

    return render_template('admin/account/account_edit.html', user=new_user,
                           roles=Role.query.filter(db.and_(Role.name != 'translator', Role.name != 'customer_manager')).all())


@auth.route('/edit_account/<int:user_id>', methods=['GET', 'POST'])
@login_required
def edit_account(user_id):
    """编辑账号"""

    for breadcrumb in session['breadcrumbs']:
        if 'Edit Account' == breadcrumb['text']:
            break
    else:
        session['breadcrumbs'].append({'text': 'Edit Account', 'url': url_for('auth.edit_account', user_id=user_id)})

    user = user = User.query.filter_by(id=user_id).first()

    if request.method == 'POST':
        other_user = User.query.filter_by(email=request.form['email']).first()
        if user.id != other_user.id:
            flash(u'此邮箱地址已注册过', 'danger')
        if request.form['password'] != request.form['password2']:
            flash(u'两次输入的密码不相同', 'danger')

        if user.password_hash != request.form['password']:
            user.password = request.form['password']

        user.username = request.form['username']
        user.email = request.form['email']
        user.role = Role.query.filter_by(id=request.form['role']).first()

        db.session.add(user)
        db.session.commit()
        flash(u'更新成功!', 'info')
        return redirect(url_for('auth.edit_account', user_id=user_id))

    return render_template('admin/account/account_edit.html', user=user,
                           roles=Role.query.filter(Role.name != 'customer_manager').all())


@auth.route('/account/add_translator', methods=['GET', 'POST'])
@login_required
def add_translator():
    """新增翻译账号"""
    for breadcrumb in session['breadcrumbs']:
        if 'New Translator' == breadcrumb['text']:
            break
    else:
        session['breadcrumbs'].append({'text': 'New Translator', 'url': url_for('auth.add_translator')})
    if request.method == 'POST':
        username = request.form['username']
        email = request.form['email']
        password = request.form['password']
        password2 = request.form['password2']
        customer_id = int(request.form['customer'])
        language_ids = request.form.getlist('language')

        other_translator = User.query.filter(User.email == email).first()
        current_app.logger.info(other_translator)
        if other_translator is not None:
            flash(u'此邮箱已注册', 'danger')
        else:
            if password != password2:
                flash(u'两次输入的密码不一致', 'danger')
            else:
                translator = Translator()
                translator.username = username
                translator.password = password
                translator.email = email
                translator.customer_id = customer_id

                for language in Language.query.filter(Language.id.in_(language_ids)):
                    translator.language.append(language)

                db.session.add(translator)
                db.session.commit()

                user = User.query.filter_by(id=translator.id).first()
                user.role = Role.query.filter_by(name='translator').first()

                db.session.add(user)
                db.session.commit()

                new_account_email_notice(request.url_root, translator.email, request.form['password'])
                flash(u'新增成功!', 'info')
                return redirect(url_for('auth.add_translator'))

    return render_template('admin/account/translator_account_edit.html',
                           translator=None, languages=Language.query.all(), customers=Customer.query.all())


@auth.route('/account/edit_translator/<int:translator_id>', methods=['GET', 'POST'])
@login_required
def edit_translator(translator_id):
    """编辑翻译账号"""

    for breadcrumb in session['breadcrumbs']:
        if 'Edit Translator' == breadcrumb['text']:
            break
    else:
        session['breadcrumbs'].append({'text': 'Edit Translator',
                                       'url': url_for('auth.edit_translator', translator_id=translator_id)})
    translator = Translator.query.filter_by(id=translator_id).first()

    if request.method == 'POST':
        username = request.form['username']
        email = request.form['email']
        password = request.form['password']
        password2 = request.form['password2']
        customer_id = int(request.form['customer'])
        language_ids = request.form.getlist('language')

        other_translator = User.query.filter_by(email=email).first()
        if other_translator is not None and other_translator.id != translator.id:
            flash(u'此邮箱已注册', 'danger')
        else:
            if password != translator.password_hash and password != password2:
                flash(u'两次输入的密码不一致', 'danger')
            else:
                translator.username = username
                if translator.password_hash != password:
                    translator.password = password
                translator.email = email
                translator.customer_id = customer_id
                translator.language = []
                for language in Language.query.filter(Language.id.in_(language_ids)):
                    translator.language.append(language)

                db.session.add(translator)
                db.session.commit()

                flash(u'修改成功!', 'info')
                return redirect(url_for('auth.edit_translator', translator_id=translator_id))

    current_app.logger.info(translator.language)
    return render_template('admin/account/translator_account_edit.html',
                           translator=translator, languages=Language.query.all(), customers=Customer.query.all())


@auth.route('/add_customer_manager', methods=['GET', 'POST'])
@login_required
def add_customer_manager():
    """新增客户管理员账号"""

    for breadcrumb in session['breadcrumbs']:
        if 'New Customer Manager' == breadcrumb['text']:
            break
    else:
        session['breadcrumbs'].append({'text': 'New Customer Manager',
                                       'url': url_for('auth.add_customer_manager')})
    customer_manager = None
    if request.method == 'POST':
        if request.form['password'] != request.form['password2']:
            flash(u'两次输入的密码不相同', 'danger')
            return redirect(url_for('auth.add_customer_manager'))

        user = User.query.filter_by(email=request.form['email']).first()
        if user is not None:
            flash(u'此邮箱地址已注册过', 'danger')
            return redirect(url_for('auth.add_customer_manager'))

        customer_manager = CustomerManager()
        customer_manager.username = request.form['username']
        customer_manager.email = request.form['email']
        customer_manager.password = request.form['password']
        customer_manager.customer = Customer.query.filter_by(id=request.form['customer']).first()
        customer_manager.description = request.form.get('description', '').strip()
        db.session.add(customer_manager)
        db.session.commit()

        role_name = request.form.get('role')
        user = User.query.filter_by(id=customer_manager.id).first()
        role = Role.query.filter_by(name=role_name).first()
        customer_manager.role = role
        db.session.add(user)
        db.session.commit()

        new_account_email_notice(request.url_root, customer_manager.email, request.form['password'])
        flash(u'新增成功', 'info')
        return redirect(url_for('auth.add_customer_manager'))

    return render_template('admin/account/customer_manager_account_edit.html', customer_manager=customer_manager,
                           roles=Role.query.all(), customers=Customer.query.filter_by(work_flow=True).all())


@auth.route('/edit_customer_manager/<int:customer_manager_id>', methods=['GET', 'POST'])
@login_required
def edit_customer_manager(customer_manager_id):
    """编辑客户管理员账号"""

    for breadcrumb in session['breadcrumbs']:
        if 'Edit Customer Manager' == breadcrumb['text']:
            break
    else:
        session['breadcrumbs'].append({'text': 'Edit Customer Manager',
                                       'url': url_for('auth.edit_customer_manager',
                                                      customer_manager_id=customer_manager_id)})

    customer_manager = CustomerManager.query.filter_by(id=customer_manager_id).first()

    if request.method == 'POST':
        other_user = User.query.filter_by(email=request.form['email']).first()
        if customer_manager.id != other_user.id:
            flash(u'此邮箱地址已注册过', 'danger')
        if request.form['password'] != request.form['password2']:
            flash(u'两次输入的密码不相同', 'danger')

        if customer_manager.password_hash != request.form['password']:
            customer_manager.password = request.form['password']

        customer_manager.username = request.form['username']
        customer_manager.email = request.form['email']
        customer_manager.role = Role.query.filter_by(name=request.form['role']).first()
        customer_manager.customer = Customer.query.filter_by(id=request.form['customer']).first()
        db.session.add(customer_manager)
        db.session.commit()
        flash(u'更新成功!', 'info')
        return redirect(url_for('auth.edit_customer_manager', customer_manager_id=customer_manager_id))

    return render_template('admin/account/customer_manager_account_edit.html', customer_manager=customer_manager,
                           roles=Role.query.all(), customers=Customer.query.filter_by(work_flow=True).all())


@auth.route('/system_menu_page')
@login_required
def system_menu_page():
    """菜单清单"""
    session['breadcrumbs'] = [session['breadcrumbs'][0]]
    session['breadcrumbs'].append({'text': 'Menu Manager', 'url': url_for('auth.system_menu_page')})
    session['menu_path'] = ['系统管理', '菜单管理']
    return render_template('admin/account/system_menu_page.html', menus=SystemMenu.query.all())


@auth.route('/add_system_menu', methods=['GET', 'POST'])
@login_required
def add_system_menu():
    """新增菜单"""

    for breadcrumb in session['breadcrumbs']:
        if 'New System Menu' == breadcrumb['text']:
            break
    else:
        session['breadcrumbs'].append({'text': 'New System Menu',
                                       'url': url_for('auth.add_system_menu')})
    if request.method == 'POST':
        name = request.form['name']
        action = request.form.get('action', '')
        activate = request.form.get('activate')
        note = request.form.get('note')
        order = request.form['order']
        parent_id = request.form['parent']

        other_menu = SystemMenu.query.filter(db.and_(SystemMenu.action == action,
                                                     SystemMenu.parent_id == parent_id)).first()
        if other_menu:
            flash(u'同名菜单存在', 'danger')
        else:
            menu = SystemMenu()
            menu.name = name
            menu.action = action or ''
            menu.note = note
            if activate == 'on':
                menu.activate = True
            else:
                menu.activate = False
            menu.style = ''
            menu.order = order
            if parent_id:
                menu.parent_id = parent_id
            db.session.add(menu)
            db.session.commit()

            flash(u'新增成功!', 'info')
            return redirect(url_for('auth.add_system_menu'))

    return render_template('admin/account/system_menu_edit.html', menu=None,
                           parent_menus=SystemMenu.query.filter(
                               db.and_(SystemMenu.action == '', SystemMenu.activate == True)).all())


@auth.route('/edit_system_menu/<int:menu_id>',  methods=['GET', 'POST'])
@login_required
def edit_system_menu(menu_id):
    """修改菜单"""

    for breadcrumb in session['breadcrumbs']:
        if 'Edit System Menu' == breadcrumb['text']:
            break
    else:
        session['breadcrumbs'].append({'text': 'Edit System Menu',
                                       'url': url_for('auth.edit_system_menu', menu_id=menu_id)})

    menu = SystemMenu.query.filter_by(id=menu_id).first()
    if request.method == 'POST':
        name = request.form['name']
        action = request.form.get('action', '')
        activate = request.form.get('activate')
        note = request.form.get('note')
        order = request.form['order']
        parent_id = request.form['parent']

        other_menu = SystemMenu.query.filter(db.and_(SystemMenu.action == action,
                                                     SystemMenu.parent_id == parent_id)).first()
        if other_menu and other_menu.id != menu.id:
            flash(u'同名菜单存在', 'danger')
        else:
            menu.name = name
            menu.action = action or ''
            menu.note = note
            if activate == 'on':
                menu.activate = True
            else:
                menu.activate = False
            menu.style = ''
            menu.order = order
            if parent_id:
                menu.parent_id = parent_id
            db.session.add(menu)
            db.session.commit()

            flash(u'修改成功!', 'info')
            return redirect(url_for('auth.edit_system_menu', menu_id=menu_id))

    return render_template('admin/account/system_menu_edit.html', menu=menu,
                           parent_menus=SystemMenu.query.filter(
                               db.and_(SystemMenu.action == '', SystemMenu.activate == True)).all())


@auth.route('/_menu_activate')
@login_required
def set_menu_activate():
    menu_id = request.args.get('id', 0, type=int)
    activate = request.args.get('activate')
    if activate == 'Enable':
        db.session.execute('UPDATE wmt_menu SET activate=1 WHERE id =%s or parent_id=%s' % (menu_id, menu_id))
    elif activate == 'Disable':
        db.session.execute('UPDATE wmt_menu SET activate=0 WHERE id =%s or parent_id=%s' % (menu_id, menu_id))
    db.session.commit()

    return '{"result": true}'


@auth.route('/role_page')
@login_required
def role_page():

    session['breadcrumbs'] = [session['breadcrumbs'][0]]
    session['breadcrumbs'].append({'text': 'Role Manager', 'url': url_for('auth.role_page')})
    session['menu_path'] = ['系统管理', '角色管理']

    roles = Role.query.all()
    return render_template('admin/account/role_page.html', roles=roles)


@auth.route('/add_role/', methods=['GET', 'POST'])
@login_required
def add_role():
    """新增角色"""

    for breadcrumb in session['breadcrumbs']:
        if 'New Role' == breadcrumb['text']:
            break
    else:
        session['breadcrumbs'].append({'text': 'New Role', 'url': url_for('auth.add_role')})

    if request.method == 'POST':
        other_role = Role.query.filter_by(name=request.form['name']).first()
        if other_role:
            flash(u'同名角色已存在', 'danger')
        else:
            all_id = [str(menu_id) for menu_id in request.form.getlist('role_menu') if menu_id]
            if all_id:
                query_sql = "SELECT DISTINCT  parent_id FROM wmt_menu WHERE id IN(%s)" % ','.join(all_id)

                current_app.logger.info(query_sql)
                for row in db.engine.execute(query_sql):
                    if row[0] != 'None' and row[0] != None:
                        current_app.logger.info(row[0])
                        all_id.append(str(row[0]))

            role = Role()
            role.menu = ','.join(list(set(all_id)))
            role.name = request.form['name']
            role.index_page = request.form['index_page']

            db.session.add(role)
            db.session.commit()

            users = User.query.filter(User.id.in_(request.form.getlist('role_remember')))
            for user in users:
                user.role = role
                db.session.add(user)
            db.session.commit()
            return redirect(url_for('auth.role_page'))

    menus = SystemMenu.query.filter_by(activate=True).order_by(SystemMenu.order).all()
    users = User.query.all()

    return render_template('admin/account/role_edit.html', role=None, menus=menus, users=users)


@auth.route('/edit_role/<int:role_id>', methods=['GET', 'POST'])
@login_required
def edit_role(role_id):
    """编辑角色"""

    for breadcrumb in session['breadcrumbs']:
        if 'Edit Role' == breadcrumb['text']:
            break
    else:
        session['breadcrumbs'].append({'text': 'Edit Role',
                                       'url': url_for('auth.edit_role', role_id=role_id)})

    role = Role.query.filter_by(id=role_id).first()

    if request.method == 'POST':
        all_id = [str(menu_id) for menu_id in request.form.getlist('role_menu') if menu_id]

        if all_id:
            query_sql = "SELECT DISTINCT  parent_id FROM wmt_menu WHERE id IN(%s)" % ','.join(all_id)

            for row in db.engine.execute(query_sql):
                if row[0] != 'None' and row[0] != None:
                    current_app.logger.info(row[0])
                    all_id.append(str(row[0]))

            role.menu = ','.join(list(set(all_id)))
        else:
            role.menu = ''

        role.name = request.form['name']
        role.index_page = request.form['index_page']

        db.session.add(role)
        db.session.commit()

        user_ids = request.form.getlist('role_remember')
        remember = User.query.filter_by(role_id=role.id).all()
        for user in remember:
            if user.id in user_ids:
                user_ids.remove(user.id)
            else:
                user.role = None
                db.session.add(user)

        users = User.query.filter(User.id.in_(user_ids))
        for user in users:
            user.role = role
            db.session.add(user)
        db.session.commit()
        return redirect(url_for('auth.role_page'))

    menus = SystemMenu.query.filter_by(activate=True).order_by(SystemMenu.order).all()
    users = User.query.all()
    if role.menu:
        role_menu = [int(id) for id in role.menu.split(',') if id]
    else:
        role_menu = []

    return render_template('admin/account/role_edit.html',
                           role=role, menus=menus, users=users, role_menu=role_menu)


@auth.route('/change_user_status', methods=['GET'])
@login_required
def change_user_status():
    """修改用户的状态(停用或激活)"""

    user_id = request.args.get('user_id', '')
    status = request.args.get('status')
    role_name = request.args.get('role_name', '')

    current_app.logger.info(role_name)
    if role_name and role_name == 'translate_agency':
        translate_agency = TranslateAgency.query.filter(TranslateAgency.id == user_id).first()
        translate_agency.activate = status
        db.session.add(translate_agency)

        user = translate_agency.user
        current_app.logger.info(user.username)
    else:
        user = User.query.filter(User.id == user_id).first()

    user.activate = status

    db.session.add(user)
    db.session.commit()

    return '{"result":true}'
