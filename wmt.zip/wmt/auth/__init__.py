# -*- coding:utf-8 -*-
__author__ = 'changjie.fan'

"""定义auth模块的蓝图"""
from flask import Blueprint

auth = Blueprint('auth', __name__)
from . import views
