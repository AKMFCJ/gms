# -*- coding:utf-8 -*-

__author__ = 'roy'
__created__ = '11/18/15'

"""客户数据库模型"""

from wmt import db
from wmt.auth.models import User


customer_language = db.Table('customer_language', db.metadata,
                             db.Column('customer_id', db.Integer, db.ForeignKey('customer.id')),
                             db.Column('language_id', db.Integer, db.ForeignKey('wmt_language.id'))
                             )


class Customer(db.Model):
    """客户"""

    __tablename__ = 'customer'

    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(80), unique=True)
    area = db.Column(db.String(80))
    language = db.relationship('Language', secondary='customer_language', backref='customer')
    # 默认都不需要客户确认流程的
    work_flow = db.Column(db.Boolean, default=False)

    def __repr__(self):
        return '<Customer %r>' % self.name


class Language(db.Model):
    """语言"""

    __tablename__ = 'wmt_language'

    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(80))
    abbreviation = db.Column(db.String(20), unique=True)

    def __repr__(self):
        return '<Language %r>' % self.name


translator_language = db.Table('translator_language', db.metadata,
                               db.Column('translator_id', db.Integer, db.ForeignKey('translator.id')),
                               db.Column('language_id', db.Integer, db.ForeignKey('wmt_language.id'))
                               )


class Translator(User):
    """翻译者"""

    __tablename__ = 'translator'

    id = db.Column(db.Integer, db.ForeignKey('wmt_user.id'), primary_key=True)
    customer_id = db.Column(db.Integer, db.ForeignKey('customer.id'))
    customer = db.relationship('Customer', backref=db.backref('translator', order_by=id))
    translate_agency_id = db.Column(db.Integer, db.ForeignKey('translate_agency.id'))
    translate_agency = db.relationship('TranslateAgency', backref=db.backref('translator', order_by=id))
    language = db.relationship('Language', secondary='translator_language', backref='translator')

    def __repr__(self):
        return '<Translator %r>' % self.username


customer_manager_language = db.Table('customer_manager_language', db.metadata,
                                     db.Column('customer_manager_id', db.Integer, db.ForeignKey('customer_manager.id')),
                                     db.Column('language_id', db.Integer, db.ForeignKey('wmt_language.id'))
                                     )


class CustomerManager(User):
    """local管理者"""

    __tablename__ = 'customer_manager'

    id = db.Column(db.Integer, db.ForeignKey('wmt_user.id'), primary_key=True)
    customer_id = db.Column(db.Integer, db.ForeignKey('customer.id'))
    customer = db.relationship('Customer', backref=db.backref('manager', order_by=id))
    language = db.relationship('Language', secondary='customer_manager_language', backref='customer_manager')

    def __repr__(self):
        return '<CustomerManager %r>' % self.customer.name


translate_agency_language = db.Table('translate_agency_language', db.metadata,
                                     db.Column('translate_agency_id', db.Integer, db.ForeignKey('translate_agency.id')),
                                     db.Column('language_id', db.Integer, db.ForeignKey('wmt_language.id'))
                                     )


class TranslateAgency(db.Model):
    """翻译机构"""

    __tablename__ = 'translate_agency'

    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100))
    customer_id = db.Column(db.Integer, db.ForeignKey('customer.id'))
    customer = db.relationship('Customer', backref=db.backref('agency', order_by=id))
    user_id = db.Column(db.Integer, db.ForeignKey('wmt_user.id'))
    user = db.relationship('User', backref=db.backref('agency', order_by=id))
    language = db.relationship('Language', secondary='translate_agency_language', backref='translate_agency')
    activate = db.Column(db.Boolean, default=True)

    def __repr__(self):
        return '<TranslateAgency %r>' % self.name
