# -*- coding:utf-8 -*-
__author__ = 'changjie.fan'

"""定义客户模块的蓝图"""
from flask import Blueprint

customer = Blueprint('customer', __name__)
from . import views

